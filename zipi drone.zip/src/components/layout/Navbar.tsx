import { AnimatePresence, motion } from 'framer-motion';
import { Heart, Menu, Search, ShoppingBag, User } from 'lucide-react';
import { useEffect, useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useShop } from '@/hooks/useShop';
import { useMegaMenu } from '@/hooks/useMegaMenu';
import { NAV_ITEMS } from '@/data/navigation';
import DesktopNav from './DesktopNav';
import Logo from './Logo';
import MegaMenuPanel from './MegaMenuPanel';
import MobileMenu from './MobileMenu';
import SearchOverlay from './SearchOverlay';
import AccountModal from './AccountModal';

type NavbarProps = {
  onOpenCart: () => void;
};

export default function Navbar({ onOpenCart }: NavbarProps) {
  const { cartCount, wishlist } = useShop();
  const { pathname } = useLocation();
  const [menuOpen, setMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [accountOpen, setAccountOpen] = useState(false);
  const { activeId, hoverItem, enterArea, leaveArea, open, close } = useMegaMenu();

  const activeItem = NAV_ITEMS.find((item) => item.id === activeId);
  const activeMenu = activeItem?.menu;

  useEffect(() => {
    setMenuOpen(false);
    close();
  }, [pathname, close]);

  const iconBtn =
    'relative rounded-full p-2.5 text-zinc-300 transition-colors duration-300 hover:bg-white/10 hover:text-white outline-none focus-visible:ring-2 focus-visible:ring-cyan-400';

  return (
    <>
      <header
        onMouseEnter={enterArea}
        onMouseLeave={leaveArea}
        onBlur={(e) => {
          const next = e.relatedTarget;
          if (next instanceof Node && !e.currentTarget.contains(next)) close();
        }}
        className="fixed inset-x-0 top-0 z-50 border-b border-white/10 bg-neutral-950/85 backdrop-blur-xl"
      >
        <div className="mx-auto flex h-20 max-w-7xl items-center gap-6 px-5 sm:px-8">
          <Logo tone="light" />

          <DesktopNav
            items={NAV_ITEMS}
            activeId={activeId}
            onHover={hoverItem}
            onOpen={open}
            onClose={close}
          />

          <div className="ml-auto flex items-center gap-1.5 sm:gap-2">
            {/* Search */}
            <button
              onClick={() => setSearchOpen(true)}
              className={iconBtn}
              aria-label="Search drones"
            >
              <Search className="h-5 w-5" />
            </button>

            {/* Account */}
            <button
              onClick={() => setAccountOpen(true)}
              className={iconBtn}
              aria-label="Account"
            >
              <User className="h-5 w-5" />
            </button>

            {/* Wishlist */}
            <Link
              to="/wishlist"
              className={iconBtn}
              aria-label={`Wishlist, ${wishlist.length} items`}
            >
              <Heart className="h-5 w-5" />
              {wishlist.length > 0 && <CountBadge value={wishlist.length} tone="cyan" />}
            </Link>

            {/* Cart */}
            <button
              onClick={onOpenCart}
              className={iconBtn}
              aria-label={`Cart, ${cartCount} items`}
            >
              <ShoppingBag className="h-5 w-5" />
              {cartCount > 0 && <CountBadge value={cartCount} tone="cyan" />}
            </button>

            {/* Mobile Menu */}
            <button
              onClick={() => setMenuOpen(true)}
              className={`${iconBtn} md:hidden`}
              aria-label="Open navigation menu"
            >
              <Menu className="h-6 w-6" />
            </button>
          </div>
        </div>

        <AnimatePresence>
          {activeItem && activeMenu && (
            <MegaMenuPanel key="mega-menu" id={activeItem.id} menu={activeMenu} onNavigate={close} />
          )}
        </AnimatePresence>
      </header>

      <MobileMenu open={menuOpen} onClose={() => setMenuOpen(false)} />
      <SearchOverlay open={searchOpen} onClose={() => setSearchOpen(false)} />
      <AccountModal open={accountOpen} onClose={() => setAccountOpen(false)} />
    </>
  );
}

function CountBadge({ value }: { value: number; tone?: 'cyan' | 'brand' }) {
  return (
    <motion.span
      key={value}
      initial={{ scale: 0.5 }}
      animate={{ scale: 1 }}
      className="absolute -right-0.5 -top-0.5 flex h-5 min-w-5 items-center justify-center rounded-full bg-cyan-400 px-1 text-[10px] font-black text-black shadow-[0_0_12px_rgba(0,229,255,0.8)]"
    >
      {value}
    </motion.span>
  );
}
