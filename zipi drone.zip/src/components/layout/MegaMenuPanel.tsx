import { AnimatePresence, motion, type Variants } from 'framer-motion';
import { ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import type { MegaMenu } from '@/data/navigation';

const EASE = [0.22, 1, 0.36, 1] as const;

const contentVariants: Variants = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: { duration: 0.25, staggerChildren: 0.06, delayChildren: 0.04 },
  },
  exit: { opacity: 0, transition: { duration: 0.15 } },
};

const itemVariants: Variants = {
  hidden: { opacity: 0, y: 14 },
  show: { opacity: 1, y: 0, transition: { duration: 0.4, ease: EASE } },
  exit: { opacity: 0, y: 6, transition: { duration: 0.15 } },
};

const arrowVariants: Variants = {
  show: { x: 0 },
  hover: { x: 6, transition: { type: 'spring', stiffness: 400, damping: 22 } },
};

const imageVariants: Variants = {
  show: { scale: 1 },
  hover: { scale: 1.06, transition: { duration: 0.9, ease: EASE } },
};

type MegaMenuPanelProps = {
  id: string;
  menu: MegaMenu;
  onNavigate: () => void;
};

export default function MegaMenuPanel({ id, menu, onNavigate }: MegaMenuPanelProps) {
  return (
    <motion.div
      id="mega-menu"
      initial={{ opacity: 0, y: -16 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -10 }}
      transition={{ duration: 0.4, ease: EASE }}
      className="absolute inset-x-0 top-full border-t border-ink-200 bg-white shadow-lift"
    >
      <div className="mx-auto max-w-7xl px-5 pb-14 pt-10 sm:px-8">
        <AnimatePresence mode="wait" initial={false}>
          <motion.div
            key={id}
            variants={contentVariants}
            initial="hidden"
            animate="show"
            exit="exit"
            className="grid gap-12 md:grid-cols-12 md:gap-16"
          >
            <div className="md:col-span-5">
              <motion.p variants={itemVariants} className="text-xs font-medium uppercase tracking-[0.2em] text-ink-500">
                {menu.eyebrow}
              </motion.p>
              <ul className="mt-8">
                {menu.links.map((link) => (
                  <motion.li
                    key={link.label}
                    variants={itemVariants}
                    whileHover="hover"
                    className="border-b border-ink-200 first:border-t"
                  >
                    <Link
                      to={link.to}
                      onClick={onNavigate}
                      className="group flex items-center justify-between rounded-md py-6 outline-none focus-visible:ring-2 focus-visible:ring-brand-500"
                    >
                      <span className="font-display text-2xl font-medium text-ink-900 transition-colors duration-300 group-hover:text-brand-600 group-focus-visible:text-brand-600 sm:text-3xl">
                        {link.label}
                      </span>
                      <motion.span
                        variants={arrowVariants}
                        className="flex text-ink-900 transition-colors duration-300 group-hover:text-brand-600"
                      >
                        <ArrowRight className="h-6 w-6" />
                      </motion.span>
                    </Link>
                  </motion.li>
                ))}
              </ul>
            </div>

            <motion.div
              variants={itemVariants}
              whileHover="hover"
              className="relative h-[380px] overflow-hidden rounded-3xl bg-ink-100 sm:h-[420px] md:col-span-7"
            >
              <div className="absolute inset-x-8 bottom-8 top-[40%] overflow-hidden rounded-2xl">
                <motion.img
                  src={menu.promo.image}
                  alt={menu.promo.imageAlt}
                  variants={imageVariants}
                  className="h-full w-full object-cover"
                />
              </div>
              <Link
                to={menu.promo.to}
                onClick={onNavigate}
                className="relative z-10 flex h-full flex-col rounded-3xl p-8 outline-none focus-visible:ring-2 focus-visible:ring-brand-500 sm:p-10"
              >
                <span className="text-xs font-semibold uppercase tracking-[0.2em] text-ink-700">
                  {menu.promo.eyebrow}
                </span>
                <span className="mt-4 max-w-md font-display text-3xl font-medium leading-tight text-ink-900 sm:text-4xl">
                  {menu.promo.headline}
                </span>
              </Link>
            </motion.div>
          </motion.div>
        </AnimatePresence>
      </div>
    </motion.div>
  );
}
