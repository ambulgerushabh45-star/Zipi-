import { motion } from 'framer-motion';
import { ArrowRight, Minus, Plus, X } from 'lucide-react';
import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useShop } from '@/hooks/useShop';
import { CATEGORY_LABELS, type Product } from '@/data/products';
import { formatPrice } from '@/lib/format';
import StarRating from './StarRating';

type QuickViewModalProps = {
  product: Product;
  onClose: () => void;
};

export default function QuickViewModal({ product, onClose }: QuickViewModalProps) {
  const { addToCart, toggleWishlist, wishlist } = useShop();
  const [color, setColor] = useState(product.colors[0].name);
  const [quantity, setQuantity] = useState(1);
  const saved = wishlist.includes(product.id);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && onClose();
    document.body.style.overflow = 'hidden';
    window.addEventListener('keydown', onKey);
    return () => {
      document.body.style.overflow = '';
      window.removeEventListener('keydown', onKey);
    };
  }, [onClose]);

  return (
    <div className="fixed inset-0 z-[65] flex items-center justify-center p-4">
      <motion.div
        className="absolute inset-0 bg-ink-900/50 backdrop-blur-sm"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
      />
      <motion.div
        role="dialog"
        aria-modal="true"
        aria-label={`Quick view: ${product.name}`}
        initial={{ opacity: 0, y: 24, scale: 0.97 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: 16, scale: 0.97 }}
        transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
        className="relative grid max-h-[90vh] w-full max-w-3xl overflow-y-auto rounded-3xl bg-white shadow-lift md:grid-cols-2"
      >
        <button
          onClick={onClose}
          className="absolute right-4 top-4 z-10 rounded-full bg-white/90 p-2 text-ink-600 shadow-glass transition hover:text-ink-900"
          aria-label="Close quick view"
        >
          <X className="h-5 w-5" />
        </button>
        <div className="bg-ink-50 md:min-h-full">
          <img src={product.image} alt={product.name} className="h-full w-full object-cover" />
        </div>
        <div className="flex flex-col gap-5 p-6 sm:p-8">
          <div>
            <p className="eyebrow">{CATEGORY_LABELS[product.category]}</p>
            <h2 className="mt-2 text-3xl font-bold">{product.name}</h2>
            <div className="mt-2">
              <StarRating rating={product.rating} count={product.reviewCount} />
            </div>
          </div>
          <p className="text-sm leading-relaxed text-ink-600">{product.tagline}</p>
          <p className="font-display text-3xl font-bold">{formatPrice(product.price)}</p>

          <div>
            <p className="mb-2 text-xs font-semibold uppercase tracking-wider text-ink-500">Color: {color}</p>
            <div className="flex gap-2">
              {product.colors.map((c) => (
                <button
                  key={c.name}
                  onClick={() => setColor(c.name)}
                  aria-label={c.name}
                  aria-pressed={color === c.name}
                  className={`h-8 w-8 rounded-full border-2 transition ${color === c.name ? 'border-brand-600 scale-110' : 'border-white ring-1 ring-ink-200'}`}
                  style={{ backgroundColor: c.hex }}
                />
              ))}
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="flex items-center rounded-full border border-ink-200">
              <button onClick={() => setQuantity((q) => Math.max(1, q - 1))} className="p-3 text-ink-600 hover:text-brand-600" aria-label="Decrease quantity">
                <Minus className="h-4 w-4" />
              </button>
              <span className="w-8 text-center font-semibold">{quantity}</span>
              <button onClick={() => setQuantity((q) => Math.min(10, q + 1))} className="p-3 text-ink-600 hover:text-brand-600" aria-label="Increase quantity">
                <Plus className="h-4 w-4" />
              </button>
            </div>
          </div>

          <div className="mt-auto flex flex-col gap-3">
            <button
              onClick={() => {
                addToCart(product.id, color, quantity);
                onClose();
              }}
              className="btn-primary w-full"
            >
              Add to cart
            </button>
            <div className="grid grid-cols-2 gap-3">
              <button onClick={() => toggleWishlist(product.id)} className="btn-ghost text-xs">
                {saved ? 'Saved' : 'Wishlist'}
              </button>
              <Link to={`/product/${product.id}`} onClick={onClose} className="btn-ghost group text-xs">
                Details
                <ArrowRight className="h-3.5 w-3.5 transition-transform group-hover:translate-x-1" />
              </Link>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
