import React from 'react';
import type { Product } from '@/data/products';

type DroneRenderProps = {
  product: Product;
  selectedColor?: string;
  className?: string;
  viewMode?: 'tactical' | 'photo';
};

export default function DroneRender({
  product,
  selectedColor,
  className = '',
  viewMode = 'tactical',
}: DroneRenderProps) {
  // If user switched to field photo view
  if (viewMode === 'photo' && product.image) {
    return (
      <div className={`relative flex items-center justify-center ${className}`}>
        <img
          src={product.image}
          alt={product.name}
          className="max-h-[55vh] w-auto rounded-3xl object-contain shadow-2xl transition-transform duration-700 hover:scale-105"
        />
        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 rounded-full border border-white/20 bg-black/80 px-4 py-1.5 text-xs uppercase tracking-widest text-cyan-400 backdrop-blur">
          Field Operational Telemetry
        </div>
      </div>
    );
  }

  // Tactical Transparent CAD/Silhouette Render according to selected drone
  return (
    <div className={`relative flex items-center justify-center select-none ${className}`}>
      {renderDroneSVG(product.id, selectedColor, product.category)}
    </div>
  );
}

function renderDroneSVG(id: string, colorHex?: string, category?: string) {
  // Color tones according to drone class
  const tone = colorHex || (category === 'defence' ? '#1c2026' : '#272e39');
  void tone;

  switch (id) {
    // -------------------------------------------------------------
    // DEFENCE: AEGIS SENTINEL MK-IV (Tactical ISR Quadcopter)
    // -------------------------------------------------------------
    case 'aegis-mk4':
      return (
        <svg viewBox="0 0 800 500" className="w-full max-h-[58vh] drop-shadow-[0_25px_35px_rgba(0,229,255,0.18)]">
          <defs>
            <radialGradient id="aegisGlow" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#00e5ff" stopOpacity="0.4" />
              <stop offset="100%" stopColor="#00e5ff" stopOpacity="0" />
            </radialGradient>
            <linearGradient id="carbonArms" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#1e2229" />
              <stop offset="50%" stopColor="#2b313c" />
              <stop offset="100%" stopColor="#15171c" />
            </linearGradient>
            <linearGradient id="fuselageGrad" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#2e3542" />
              <stop offset="60%" stopColor="#1b1f26" />
              <stop offset="100%" stopColor="#0f1115" />
            </linearGradient>
          </defs>

          {/* Underglow & Ground Shadows */}
          <ellipse cx="400" cy="460" rx="260" ry="24" fill="#000000" opacity="0.8" />
          <ellipse cx="400" cy="460" rx="180" ry="16" fill="url(#aegisGlow)" />

          {/* Rear Left Arm */}
          <polygon points="400,240 180,140 195,128 400,230" fill="url(#carbonArms)" stroke="#00e5ff" strokeWidth="0.5" strokeOpacity="0.4" />
          {/* Rear Right Arm */}
          <polygon points="400,240 620,140 605,128 400,230" fill="url(#carbonArms)" stroke="#00e5ff" strokeWidth="0.5" strokeOpacity="0.4" />

          {/* Rear Rotors */}
          <ellipse cx="180" cy="135" rx="100" ry="24" fill="#00e5ff" fillOpacity="0.08" stroke="#00e5ff" strokeWidth="1.2" strokeDasharray="6 4" />
          <ellipse cx="620" cy="135" rx="100" ry="24" fill="#00e5ff" fillOpacity="0.08" stroke="#00e5ff" strokeWidth="1.2" strokeDasharray="6 4" />
          <circle cx="180" cy="135" r="16" fill="#111317" stroke="#333b47" strokeWidth="2" />
          <circle cx="620" cy="135" r="16" fill="#111317" stroke="#333b47" strokeWidth="2" />

          {/* Front Left Arm */}
          <polygon points="400,260 140,340 160,355 400,275" fill="url(#carbonArms)" stroke="#00e5ff" strokeWidth="0.7" strokeOpacity="0.5" />
          {/* Front Right Arm */}
          <polygon points="400,260 660,340 640,355 400,275" fill="url(#carbonArms)" stroke="#00e5ff" strokeWidth="0.7" strokeOpacity="0.5" />

          {/* Landing Skids */}
          <path d="M 270 330 L 260 410 L 230 420" stroke="#374151" strokeWidth="8" strokeLinecap="round" strokeLinejoin="round" fill="none" />
          <path d="M 530 330 L 540 410 L 570 420" stroke="#374151" strokeWidth="8" strokeLinecap="round" strokeLinejoin="round" fill="none" />
          <line x1="200" y1="422" x2="310" y2="422" stroke="#1f2937" strokeWidth="9" strokeLinecap="round" />
          <line x1="490" y1="422" x2="600" y2="422" stroke="#1f2937" strokeWidth="9" strokeLinecap="round" />

          {/* Front Rotors */}
          <ellipse cx="150" cy="348" rx="125" ry="32" fill="#00e5ff" fillOpacity="0.12" stroke="#00e5ff" strokeWidth="1.5" />
          <ellipse cx="650" cy="348" rx="125" ry="32" fill="#00e5ff" fillOpacity="0.12" stroke="#00e5ff" strokeWidth="1.5" />
          {/* Propeller Blades Spinning Motion blur */}
          <path d="M 30 348 C 90 325 210 370 270 348" stroke="#ffffff" strokeWidth="3" strokeOpacity="0.6" strokeLinecap="round" />
          <path d="M 530 348 C 590 325 710 370 770 348" stroke="#ffffff" strokeWidth="3" strokeOpacity="0.6" strokeLinecap="round" />

          {/* Front Motor Pods with Cyan LED */}
          <circle cx="150" cy="348" r="22" fill="#111317" stroke="#4b5563" strokeWidth="3" />
          <circle cx="150" cy="348" r="8" fill="#00e5ff" className="animate-pulse" />
          <circle cx="650" cy="348" r="22" fill="#111317" stroke="#4b5563" strokeWidth="3" />
          <circle cx="650" cy="348" r="8" fill="#00e5ff" className="animate-pulse" />

          {/* Center Tactical Fuselage */}
          <polygon
            points="400,165 470,225 460,320 400,345 340,320 330,225"
            fill="url(#fuselageGrad)"
            stroke="#00e5ff"
            strokeWidth="1.5"
            strokeOpacity="0.7"
          />
          {/* Stealth Faceting lines */}
          <polygon points="400,165 435,240 400,280 365,240" fill="#222934" stroke="#374151" strokeWidth="1" />
          <line x1="400" y1="165" x2="400" y2="280" stroke="#00e5ff" strokeWidth="1.5" strokeOpacity="0.8" />
          <circle cx="400" cy="220" r="14" fill="#111827" stroke="#00e5ff" strokeWidth="1.5" />
          <circle cx="400" cy="220" r="6" fill="#00e5ff" />

          {/* EO/IR Thermal Turret Ball Gimbal (Shooting Functions hotspot target) */}
          <g transform="translate(400, 340)">
            <rect x="-35" y="-10" width="70" height="20" rx="8" fill="#1f2937" stroke="#4b5563" strokeWidth="1.5" />
            <circle cx="0" cy="18" r="30" fill="#0f172a" stroke="#00e5ff" strokeWidth="2.5" />
            {/* Primary Optical Zoom Lens */}
            <circle cx="-10" cy="16" r="13" fill="#0284c7" stroke="#38bdf8" strokeWidth="1.5" />
            <circle cx="-10" cy="16" r="6" fill="#0369a1" />
            <circle cx="-12" cy="14" r="2.5" fill="#ffffff" />
            {/* FLIR Radiometric Thermal Sensor */}
            <circle cx="14" cy="18" r="8" fill="#312e81" stroke="#a855f7" strokeWidth="1.5" />
            <circle cx="14" cy="18" r="3" fill="#c084fc" />
          </g>

          {/* Military HUD Crosshairs & Telemetry overlay */}
          <text x="400" y="440" fill="#00e5ff" fontSize="11" fontFamily="monospace" letterSpacing="4" textAnchor="middle" opacity="0.8">
            ZIPI TACTICAL ISR // SENSOR LOCK [4K EO + FLIR]
          </text>
        </svg>
      );

    // -------------------------------------------------------------
    // DEFENCE: RECON RAVEN V2 (Ultra-Silent Stealth Quad)
    // -------------------------------------------------------------
    case 'recon-raven':
      return (
        <svg viewBox="0 0 800 500" className="w-full max-h-[58vh] drop-shadow-[0_25px_35px_rgba(0,229,255,0.15)]">
          <defs>
            <radialGradient id="ravenGlow" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#00e5ff" stopOpacity="0.3" />
              <stop offset="100%" stopColor="#000000" stopOpacity="0" />
            </radialGradient>
            <linearGradient id="stealthGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#23272f" />
              <stop offset="50%" stopColor="#14171c" />
              <stop offset="100%" stopColor="#0b0d10" />
            </linearGradient>
          </defs>

          <ellipse cx="400" cy="455" rx="240" ry="20" fill="url(#ravenGlow)" />

          {/* Swept Stealth Arms */}
          <path d="M 400 230 Q 280 160 160 150" stroke="#1f242d" strokeWidth="22" strokeLinecap="round" fill="none" />
          <path d="M 400 230 Q 520 160 640 150" stroke="#1f242d" strokeWidth="22" strokeLinecap="round" fill="none" />
          <path d="M 400 260 Q 280 330 150 350" stroke="#252b35" strokeWidth="26" strokeLinecap="round" fill="none" />
          <path d="M 400 260 Q 520 330 650 350" stroke="#252b35" strokeWidth="26" strokeLinecap="round" fill="none" />

          {/* Silent Serrated Rotors */}
          <ellipse cx="160" cy="148" rx="105" ry="22" fill="#00e5ff" fillOpacity="0.06" stroke="#00e5ff" strokeWidth="1" strokeDasharray="3 3" />
          <ellipse cx="640" cy="148" rx="105" ry="22" fill="#00e5ff" fillOpacity="0.06" stroke="#00e5ff" strokeWidth="1" strokeDasharray="3 3" />
          <ellipse cx="150" cy="350" rx="130" ry="30" fill="#00e5ff" fillOpacity="0.09" stroke="#00e5ff" strokeWidth="1.2" />
          <ellipse cx="650" cy="350" rx="130" ry="30" fill="#00e5ff" fillOpacity="0.09" stroke="#00e5ff" strokeWidth="1.2" />

          {/* Low-Noise Propellers */}
          <circle cx="150" cy="350" r="18" fill="#0f1115" stroke="#374151" strokeWidth="2" />
          <circle cx="650" cy="350" r="18" fill="#0f1115" stroke="#374151" strokeWidth="2" />

          {/* Aerodynamic Stealth Body */}
          <path
            d="M 400 150 L 460 220 L 450 320 L 400 350 L 350 320 L 340 220 Z"
            fill="url(#stealthGrad)"
            stroke="#00e5ff"
            strokeWidth="1.2"
            strokeOpacity="0.6"
          />
          {/* Top Starlight Radar Dome */}
          <ellipse cx="400" cy="240" rx="28" ry="18" fill="#181c22" stroke="#333b47" strokeWidth="1.5" />
          <circle cx="400" cy="240" r="6" fill="#00e5ff" className="animate-pulse" />

          {/* Starlight Night-Vision Optical Gimbal */}
          <circle cx="400" cy="340" r="24" fill="#0f172a" stroke="#00e5ff" strokeWidth="2" />
          <circle cx="400" cy="340" r="12" fill="#0284c7" />
          <circle cx="400" cy="340" r="5" fill="#38bdf8" />

          <text x="400" y="435" fill="#00e5ff" fontSize="11" fontFamily="monospace" letterSpacing="4" textAnchor="middle" opacity="0.8">
            ZIPI STEALTH RECON // ACOUSTIC PROFILE &lt; 38 dB
          </text>
        </svg>
      );

    // -------------------------------------------------------------
    // DEFENCE: GUARDIAN SENTRY-X (Perimeter Security Hexacopter)
    // -------------------------------------------------------------
    case 'guardian-sentry':
      return (
        <svg viewBox="0 0 800 500" className="w-full max-h-[58vh] drop-shadow-[0_25px_35px_rgba(0,229,255,0.2)]">
          <ellipse cx="400" cy="460" rx="270" ry="22" fill="#000000" opacity="0.8" />
          {/* Hexacopter 6-Arm Geometry */}
          <line x1="400" y1="250" x2="160" y2="150" stroke="#1f2937" strokeWidth="18" strokeLinecap="round" />
          <line x1="400" y1="250" x2="640" y2="150" stroke="#1f2937" strokeWidth="18" strokeLinecap="round" />
          <line x1="400" y1="250" x2="120" y2="260" stroke="#283241" strokeWidth="18" strokeLinecap="round" />
          <line x1="400" y1="250" x2="680" y2="260" stroke="#283241" strokeWidth="18" strokeLinecap="round" />
          <line x1="400" y1="250" x2="180" y2="370" stroke="#313d4f" strokeWidth="20" strokeLinecap="round" />
          <line x1="400" y1="250" x2="620" y2="370" stroke="#313d4f" strokeWidth="20" strokeLinecap="round" />

          {/* 6 Rotors with Blue Ring Indicators */}
          {[
            { cx: 160, cy: 150, rx: 75, ry: 20 },
            { cx: 640, cy: 150, rx: 75, ry: 20 },
            { cx: 120, cy: 260, rx: 85, ry: 22 },
            { cx: 680, cy: 260, rx: 85, ry: 22 },
            { cx: 180, cy: 370, rx: 95, ry: 26 },
            { cx: 620, cy: 370, rx: 95, ry: 26 },
          ].map((r, i) => (
            <g key={i}>
              <ellipse cx={r.cx} cy={r.cy} rx={r.rx} ry={r.ry} fill="#00e5ff" fillOpacity="0.08" stroke="#00e5ff" strokeWidth="1.2" />
              <circle cx={r.cx} cy={r.cy} r="14" fill="#111827" stroke="#4b5563" strokeWidth="2" />
              <circle cx={r.cx} cy={r.cy} r="5" fill="#00e5ff" />
            </g>
          ))}

          {/* Heavy Magnesium Hexacopter Body */}
          <polygon points="400,160 470,205 470,295 400,340 330,295 330,205" fill="#1e242f" stroke="#00e5ff" strokeWidth="2" />
          {/* Top 360 LIDAR Scanner Hub */}
          <rect x="375" y="140" width="50" height="24" rx="6" fill="#0f172a" stroke="#00e5ff" strokeWidth="1.5" />
          <line x1="385" y1="152" x2="415" y2="152" stroke="#00e5ff" strokeWidth="3" className="animate-pulse" />

          {/* 360° Rotating Dual-Lens Turret */}
          <circle cx="400" cy="330" r="28" fill="#090d16" stroke="#00e5ff" strokeWidth="2.5" />
          <circle cx="390" cy="328" r="10" fill="#0284c7" />
          <circle cx="412" cy="332" r="7" fill="#7c3aed" />

          <text x="400" y="445" fill="#00e5ff" fontSize="11" fontFamily="monospace" letterSpacing="4" textAnchor="middle" opacity="0.8">
            ZIPI HEX-ROTOR SENTRY // PERIMETER LIDAR ACTIVE
          </text>
        </svg>
      );

    // -------------------------------------------------------------
    // DEFENCE: VALKYRIE SAR-9 (Search & Rescue Platform)
    // -------------------------------------------------------------
    case 'valkyrie-sar':
      return (
        <svg viewBox="0 0 800 500" className="w-full max-h-[58vh] drop-shadow-[0_25px_35px_rgba(230,81,0,0.25)]">
          <ellipse cx="400" cy="460" rx="260" ry="22" fill="#000000" opacity="0.8" />
          {/* Rescue Orange Livery Accents */}
          <line x1="400" y1="250" x2="160" y2="150" stroke="#e65100" strokeWidth="16" strokeLinecap="round" />
          <line x1="400" y1="250" x2="640" y2="150" stroke="#e65100" strokeWidth="16" strokeLinecap="round" />
          <line x1="400" y1="250" x2="140" y2="350" stroke="#e65100" strokeWidth="22" strokeLinecap="round" />
          <line x1="400" y1="250" x2="660" y2="350" stroke="#e65100" strokeWidth="22" strokeLinecap="round" />

          {/* Rotors with orange safety tips */}
          <ellipse cx="140" cy="350" rx="120" ry="32" fill="#ea580c" fillOpacity="0.1" stroke="#ea580c" strokeWidth="1.5" />
          <ellipse cx="660" cy="350" rx="120" ry="32" fill="#ea580c" fillOpacity="0.1" stroke="#ea580c" strokeWidth="1.5" />

          {/* Fuselage in White & Rescue High-Viz Orange */}
          <polygon points="400,165 465,225 455,330 400,355 345,330 335,225" fill="#f8fafc" stroke="#e65100" strokeWidth="3" />
          <polygon points="400,165 440,250 400,300 360,250" fill="#ea580c" />

          {/* 12,000-Lumen High-Intensity Dual Searchlight (Shooting functions target) */}
          <g transform="translate(400, 355)">
            <rect x="-45" y="0" width="90" height="26" rx="8" fill="#1e293b" stroke="#e65100" strokeWidth="2" />
            {/* Left Beam */}
            <circle cx="-22" cy="13" r="9" fill="#fef08a" stroke="#ca8a04" strokeWidth="2" className="animate-pulse" />
            {/* Right Beam */}
            <circle cx="22" cy="13" r="9" fill="#fef08a" stroke="#ca8a04" strokeWidth="2" className="animate-pulse" />
            {/* Winch Emergency Hook */}
            <line x1="0" y1="26" x2="0" y2="50" stroke="#f97316" strokeWidth="3" />
            <path d="M -5 50 Q 0 60 8 52" stroke="#f97316" strokeWidth="3" fill="none" />
          </g>

          <text x="400" y="445" fill="#ea580c" fontSize="11" fontFamily="monospace" letterSpacing="4" textAnchor="middle" opacity="0.9">
            ZIPI SEARCH &amp; RESCUE // 12,000 LM ILLUMINATOR + HOOK
          </text>
        </svg>
      );

    // -------------------------------------------------------------
    // AGRICULTURE: TERRA SPRAY X40 (40-Liter Precision Spray Rig)
    // -------------------------------------------------------------
    case 'terra-spray-x40':
      return (
        <svg viewBox="0 0 800 500" className="w-full max-h-[58vh] drop-shadow-[0_25px_35px_rgba(16,185,129,0.28)]">
          <defs>
            <radialGradient id="agriGlow" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#10b981" stopOpacity="0.35" />
              <stop offset="100%" stopColor="#10b981" stopOpacity="0" />
            </radialGradient>
            <linearGradient id="tankGrad" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#34d399" stopOpacity="0.8" />
              <stop offset="50%" stopColor="#059669" stopOpacity="0.9" />
              <stop offset="100%" stopColor="#064e3b" stopOpacity="0.95" />
            </linearGradient>
          </defs>

          {/* Ground Mist & Droplet Atmosphere */}
          <ellipse cx="400" cy="460" rx="300" ry="24" fill="url(#agriGlow)" />
          {/* Spray Droplets Misting downward */}
          <g opacity="0.6">
            <line x1="160" y1="380" x2="130" y2="445" stroke="#34d399" strokeWidth="1.5" strokeDasharray="4 6" />
            <line x1="220" y1="380" x2="200" y2="450" stroke="#34d399" strokeWidth="1.5" strokeDasharray="3 5" />
            <line x1="280" y1="380" x2="270" y2="452" stroke="#34d399" strokeWidth="1.5" strokeDasharray="4 6" />
            <line x1="520" y1="380" x2="530" y2="452" stroke="#34d399" strokeWidth="1.5" strokeDasharray="4 6" />
            <line x1="580" y1="380" x2="600" y2="450" stroke="#34d399" strokeWidth="1.5" strokeDasharray="3 5" />
            <line x1="640" y1="380" x2="670" y2="445" stroke="#34d399" strokeWidth="1.5" strokeDasharray="4 6" />
          </g>

          {/* Heavy Industrial Carbon Boom Arms */}
          <line x1="400" y1="240" x2="160" y2="170" stroke="#1f2937" strokeWidth="26" strokeLinecap="round" />
          <line x1="400" y1="240" x2="640" y2="170" stroke="#1f2937" strokeWidth="26" strokeLinecap="round" />
          <line x1="400" y1="270" x2="130" y2="340" stroke="#252f3e" strokeWidth="28" strokeLinecap="round" />
          <line x1="400" y1="270" x2="670" y2="340" stroke="#252f3e" strokeWidth="28" strokeLinecap="round" />

          {/* Massive Heavy-Lift Agricultural Rotors */}
          <ellipse cx="160" cy="168" rx="110" ry="24" fill="#10b981" fillOpacity="0.09" stroke="#10b981" strokeWidth="1.5" />
          <ellipse cx="640" cy="168" rx="110" ry="24" fill="#10b981" fillOpacity="0.09" stroke="#10b981" strokeWidth="1.5" />
          <ellipse cx="130" cy="340" rx="140" ry="32" fill="#10b981" fillOpacity="0.14" stroke="#10b981" strokeWidth="2" />
          <ellipse cx="670" cy="340" rx="140" ry="32" fill="#10b981" fillOpacity="0.14" stroke="#10b981" strokeWidth="2" />

          {/* Motor Pods with Cyber-Green Rings */}
          <circle cx="130" cy="340" r="26" fill="#111827" stroke="#10b981" strokeWidth="3" />
          <circle cx="670" cy="340" r="26" fill="#111827" stroke="#10b981" strokeWidth="3" />

          {/* Extended Spray Bar Below Arms (16-Nozzle Centrifugal System) */}
          <line x1="120" y1="375" x2="680" y2="375" stroke="#374151" strokeWidth="8" strokeLinecap="round" />
          {/* Spray Nozzles */}
          {[140, 190, 240, 290, 340, 460, 510, 560, 610, 660].map((nx) => (
            <g key={nx} transform={`translate(${nx}, 375)`}>
              <rect x="-4" y="0" width="8" height="12" fill="#10b981" rx="2" />
              <polygon points="-5,12 5,12 0,18" fill="#34d399" />
            </g>
          ))}

          {/* 40-Liter Translucent Liquid Tank in Fuselage */}
          <rect x="330" y="190" width="140" height="135" rx="28" fill="url(#tankGrad)" stroke="#10b981" strokeWidth="3" />
          {/* Liquid Level Gauge */}
          <line x1="345" y1="240" x2="455" y2="240" stroke="#ffffff" strokeWidth="2" strokeDasharray="6 4" opacity="0.7" />
          <text x="400" y="270" fill="#ffffff" fontSize="16" fontWeight="bold" textAnchor="middle" letterSpacing="2">
            40 LITER
          </text>
          <text x="400" y="290" fill="#a7f3d0" fontSize="10" textAnchor="middle" letterSpacing="1">
            CENTRIFUGAL ATOMIZER
          </text>

          {/* Dual RTK Antennas on Top */}
          <line x1="365" y1="190" x2="365" y2="155" stroke="#9ca3af" strokeWidth="4" />
          <circle cx="365" cy="152" r="8" fill="#10b981" />
          <line x1="435" y1="190" x2="435" y2="155" stroke="#9ca3af" strokeWidth="4" />
          <circle cx="435" cy="152" r="8" fill="#10b981" />

          {/* Dual Spherical Millimeter-Wave Radar on Nose */}
          <ellipse cx="400" cy="335" rx="30" ry="18" fill="#111827" stroke="#10b981" strokeWidth="2" />
          <circle cx="400" cy="335" r="7" fill="#10b981" className="animate-pulse" />

          <text x="400" y="445" fill="#10b981" fontSize="11" fontFamily="monospace" letterSpacing="4" textAnchor="middle">
            ZIPI TERRA SPRAY // 45 ACRES/HR AUTONOMOUS
          </text>
        </svg>
      );

    // -------------------------------------------------------------
    // AGRICULTURE: AGRISCAN NDVI PRO (Multispectral Crop Scanner)
    // -------------------------------------------------------------
    case 'agriscan-ndvi':
      return (
        <svg viewBox="0 0 800 500" className="w-full max-h-[58vh] drop-shadow-[0_25px_35px_rgba(5,150,105,0.22)]">
          <ellipse cx="400" cy="460" rx="240" ry="20" fill="#000000" opacity="0.8" />
          {/* Carbon Arms */}
          <line x1="400" y1="240" x2="160" y2="150" stroke="#1f2937" strokeWidth="18" strokeLinecap="round" />
          <line x1="400" y1="240" x2="640" y2="150" stroke="#1f2937" strokeWidth="18" strokeLinecap="round" />
          <line x1="400" y1="260" x2="150" y2="350" stroke="#2c3645" strokeWidth="22" strokeLinecap="round" />
          <line x1="400" y1="260" x2="650" y2="350" stroke="#2c3645" strokeWidth="22" strokeLinecap="round" />

          {/* Rotors */}
          <ellipse cx="150" cy="350" rx="125" ry="30" fill="#059669" fillOpacity="0.1" stroke="#059669" strokeWidth="1.5" />
          <ellipse cx="650" cy="350" rx="125" ry="30" fill="#059669" fillOpacity="0.1" stroke="#059669" strokeWidth="1.5" />

          {/* Aerodynamic White / Green Body */}
          <polygon points="400,160 460,225 450,325 400,350 350,325 340,225" fill="#f8fafc" stroke="#059669" strokeWidth="2.5" />
          <circle cx="400" cy="225" r="18" fill="#10b981" />
          <text x="400" y="230" fill="#ffffff" fontSize="11" fontWeight="bold" textAnchor="middle">NDVI</text>

          {/* 5-Band Multispectral Camera Array (Belly-Mounted) */}
          <g transform="translate(400, 345)">
            <rect x="-45" y="-10" width="90" height="26" rx="8" fill="#0f172a" stroke="#059669" strokeWidth="2" />
            {/* 5 Synchronized Optical Lenses (RGB, Red, Green, RedEdge, NIR) */}
            <circle cx="-32" cy="3" r="5" fill="#ef4444" stroke="#ffffff" strokeWidth="1" />
            <circle cx="-16" cy="3" r="5" fill="#22c55e" stroke="#ffffff" strokeWidth="1" />
            <circle cx="0" cy="3" r="5" fill="#3b82f6" stroke="#ffffff" strokeWidth="1" />
            <circle cx="16" cy="3" r="5" fill="#d97706" stroke="#ffffff" strokeWidth="1" />
            <circle cx="32" cy="3" r="5" fill="#8b5cf6" stroke="#ffffff" strokeWidth="1" />
          </g>

          <text x="400" y="440" fill="#10b981" fontSize="11" fontFamily="monospace" letterSpacing="4" textAnchor="middle">
            ZIPI AGRISCAN // 5-BAND MULTISPECTRAL RADIOMETER
          </text>
        </svg>
      );

    // -------------------------------------------------------------
    // DEFAULT & COMMERCIAL: APEX PRO / HORIZON / VISTA / OTHERS
    // -------------------------------------------------------------
    default:
      return (
        <svg viewBox="0 0 800 500" className="w-full max-h-[58vh] drop-shadow-[0_25px_35px_rgba(56,189,248,0.2)]">
          <ellipse cx="400" cy="460" rx="250" ry="22" fill="#000000" opacity="0.8" />
          <line x1="400" y1="240" x2="160" y2="150" stroke="#1f2937" strokeWidth="20" strokeLinecap="round" />
          <line x1="400" y1="240" x2="640" y2="150" stroke="#1f2937" strokeWidth="20" strokeLinecap="round" />
          <line x1="400" y1="260" x2="140" y2="350" stroke="#2a3442" strokeWidth="24" strokeLinecap="round" />
          <line x1="400" y1="260" x2="660" y2="350" stroke="#2a3442" strokeWidth="24" strokeLinecap="round" />

          {/* Rotors */}
          <ellipse cx="140" cy="350" rx="130" ry="32" fill="#38bdf8" fillOpacity="0.1" stroke="#38bdf8" strokeWidth="1.5" />
          <ellipse cx="660" cy="350" rx="130" ry="32" fill="#38bdf8" fillOpacity="0.1" stroke="#38bdf8" strokeWidth="1.5" />

          {/* Premium Aerospace Body */}
          <polygon points="400,165 465,225 455,325 400,350 345,325 335,225" fill="#f8fafc" stroke="#38bdf8" strokeWidth="2" />
          <circle cx="400" cy="235" r="22" fill="#0f172a" stroke="#38bdf8" strokeWidth="2" />
          <circle cx="400" cy="235" r="8" fill="#38bdf8" className="animate-pulse" />

          {/* 3-Axis Gimbal Cinema Camera */}
          <g transform="translate(400, 345)">
            <circle cx="0" cy="12" r="26" fill="#090d16" stroke="#38bdf8" strokeWidth="2" />
            <circle cx="0" cy="12" r="14" fill="#0284c7" />
            <circle cx="-3" cy="9" r="4" fill="#ffffff" />
          </g>

          <text x="400" y="440" fill="#38bdf8" fontSize="11" fontFamily="monospace" letterSpacing="4" textAnchor="middle">
            ZIPI ADVANCED AEROSPACE ARCHITECTURE // 4K CINEMA
          </text>
        </svg>
      );
  }
}
