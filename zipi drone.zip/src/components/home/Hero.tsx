import { motion, useScroll, useTransform, useMotionValue, useSpring } from 'framer-motion';
import { ArrowRight, ChevronDown, Shield, Sprout, Sparkles } from 'lucide-react';
import { useRef, type MouseEvent } from 'react';
import { Link } from 'react-router-dom';

const HERO_BG =
  'https://images.pexels.com/photos/17854251/pexels-photo-17854251.jpeg?auto=compress&cs=tinysrgb&w=1920';

export default function Hero({ onOpenShowcase }: { onOpenShowcase?: (id: string) => void }) {
  const containerRef = useRef<HTMLDivElement>(null);
  const { scrollY } = useScroll();
  const bgY = useTransform(scrollY, [0, 800], [0, 160]);
  const contentY = useTransform(scrollY, [0, 600], [0, 80]);
  const opacity = useTransform(scrollY, [0, 500], [1, 0.2]);

  // Interactive 3D Parallax on Drone
  const mouseX = useMotionValue(0.5);
  const mouseY = useMotionValue(0.5);
  const rotateX = useSpring(useTransform(mouseY, [0, 1], [10, -10]), { stiffness: 150, damping: 20 });
  const rotateY = useSpring(useTransform(mouseX, [0, 1], [-12, 12]), { stiffness: 150, damping: 20 });

  const handleMouseMove = (e: MouseEvent<HTMLDivElement>) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    mouseX.set((e.clientX - rect.left) / rect.width);
    mouseY.set((e.clientY - rect.top) / rect.height);
  };

  const handleMouseLeave = () => {
    mouseX.set(0.5);
    mouseY.set(0.5);
  };

  return (
    <section
      ref={containerRef}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      className="relative isolate min-h-[100svh] w-full overflow-hidden bg-black text-white pt-24 pb-16 flex flex-col justify-center select-none"
    >
      {/* Background with Atmospheric Lighting & Subtle Grid */}
      <motion.div style={{ y: bgY }} className="absolute inset-0 -z-20 h-[120%]">
        <img
          src={HERO_BG}
          alt="ZIPI Mission Drone Platform"
          className="h-full w-full object-cover object-center opacity-30 filter brightness-75 contrast-125"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black via-black/80 to-black" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(0,229,255,0.08)_0,transparent_70%)]" />
      </motion.div>

      {/* Cybernetic Flight HUD Elements */}
      <div className="pointer-events-none absolute inset-0 -z-10 overflow-hidden opacity-30">
        <div className="absolute left-8 top-32 flex flex-col font-mono text-[10px] tracking-widest text-cyan-400">
          <span>SYS.VER // 4.8.2</span>
          <span>LAT: 37°48'N // LON: 122°24'W</span>
          <span>RADAR: ACTIVE (360°)</span>
        </div>
        <div className="absolute right-8 top-32 flex flex-col text-right font-mono text-[10px] tracking-widest text-cyan-400">
          <span>C2 LINK: AES-256 SECURED</span>
          <span>TELEMETRY: OPTIMAL</span>
          <span>THREAT DEF: 0.00</span>
        </div>
      </div>

      <motion.div
        style={{ y: contentY, opacity }}
        className="relative mx-auto flex max-w-7xl flex-col items-center justify-center px-5 sm:px-8 text-center"
      >
        {/* Brand Tagline Eyebrow */}
        <motion.div
          initial={{ opacity: 0, y: -16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7 }}
          className="inline-flex items-center gap-2.5 rounded-full border border-cyan-500/30 bg-cyan-950/40 px-4 py-1.5 backdrop-blur-md"
        >
          <span className="flex h-2 w-2 rounded-full bg-cyan-400 animate-ping" />
          <span className="text-[11px] font-bold uppercase tracking-[0.3em] text-cyan-300">
            Advanced Autonomous Aerial Systems
          </span>
        </motion.div>

        {/* Main Heading requested by prompt */}
        <motion.h1
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.9, delay: 0.15, ease: [0.22, 1, 0.36, 1] }}
          className="mt-6 max-w-5xl font-display text-4xl font-extrabold leading-[1.08] tracking-tight sm:text-6xl md:text-7xl lg:text-8xl"
        >
          ENGINEERED FOR THE FUTURE.
          <span className="block bg-gradient-to-r from-white via-cyan-200 to-cyan-400 bg-clip-text text-transparent">
            BUILT FOR THE MISSION.
          </span>
        </motion.h1>

        {/* Supporting text requested by prompt */}
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.35 }}
          className="mt-6 max-w-2xl text-base leading-relaxed text-zinc-300 sm:text-lg md:text-xl font-light"
        >
          Advanced aerial technology transforming defence, agriculture and industries.
        </motion.p>

        {/* CENTER INTERACTIVE 3D DRONE VISUAL */}
        <motion.div
          style={{ rotateX, rotateY, transformStyle: 'preserve-3d' }}
          initial={{ opacity: 0, scale: 0.88 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1.1, delay: 0.45, ease: [0.22, 1, 0.36, 1] }}
          className="relative mt-8 sm:mt-10 w-full max-w-3xl cursor-pointer"
          onClick={() => onOpenShowcase && onOpenShowcase('aegis-mk4')}
        >
          {/* Cyan Glow Halo under Drone */}
          <div className="absolute inset-0 bg-gradient-to-t from-cyan-500/20 via-transparent to-transparent blur-3xl -z-10" />

          {/* Floating Realistic Drone Render */}
          <div className="animate-float">
            <svg viewBox="0 0 800 420" className="w-full drop-shadow-[0_20px_40px_rgba(0,229,255,0.3)]">
              {/* Drone Body & Wings Vector */}
              <ellipse cx="400" cy="380" rx="240" ry="20" fill="#000000" opacity="0.8" />
              {/* Arms */}
              <polygon points="400,200 160,110 180,95 400,190" fill="#1e2229" stroke="#00e5ff" strokeWidth="0.8" strokeOpacity="0.6" />
              <polygon points="400,200 640,110 620,95 400,190" fill="#1e2229" stroke="#00e5ff" strokeWidth="0.8" strokeOpacity="0.6" />
              <polygon points="400,220 130,290 150,310 400,235" fill="#252b35" stroke="#00e5ff" strokeWidth="1" strokeOpacity="0.8" />
              <polygon points="400,220 670,290 650,310 400,235" fill="#252b35" stroke="#00e5ff" strokeWidth="1" strokeOpacity="0.8" />

              {/* Rotors with spinning effect */}
              <ellipse cx="170" cy="102" rx="105" ry="24" fill="#00e5ff" fillOpacity="0.12" stroke="#00e5ff" strokeWidth="1.5" />
              <ellipse cx="630" cy="102" rx="105" ry="24" fill="#00e5ff" fillOpacity="0.12" stroke="#00e5ff" strokeWidth="1.5" />
              <ellipse cx="140" cy="300" rx="135" ry="32" fill="#00e5ff" fillOpacity="0.18" stroke="#00e5ff" strokeWidth="2" />
              <ellipse cx="660" cy="300" rx="135" ry="32" fill="#00e5ff" fillOpacity="0.18" stroke="#00e5ff" strokeWidth="2" />

              {/* Center Fuselage */}
              <polygon points="400,120 480,185 470,285 400,315 330,285 320,185" fill="#181c22" stroke="#00e5ff" strokeWidth="2" />
              <polygon points="400,120 440,200 400,250 360,200" fill="#252c38" />
              <circle cx="400" cy="180" r="16" fill="#0f172a" stroke="#00e5ff" strokeWidth="2" />
              <circle cx="400" cy="180" r="6" fill="#00e5ff" className="animate-pulse" />

              {/* Gimbal Turret */}
              <circle cx="400" cy="310" r="28" fill="#0a0e17" stroke="#00e5ff" strokeWidth="2.5" />
              <circle cx="390" cy="308" r="10" fill="#0284c7" />
              <circle cx="412" cy="312" r="7" fill="#7c3aed" />

              {/* Telemetry pill */}
              <rect x="300" y="360" width="200" height="26" rx="13" fill="#090d16" stroke="#00e5ff" strokeWidth="1" strokeOpacity="0.5" />
              <text x="400" y="377" fill="#00e5ff" fontSize="11" fontFamily="monospace" letterSpacing="3" textAnchor="middle">
                CLICK TO LAUNCH SHOWCASE
              </text>
            </svg>
          </div>
        </motion.div>

        {/* PRIMARY CTA ACTIONS */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.65 }}
          className="mt-8 flex flex-wrap items-center justify-center gap-4"
        >
          <Link
            to="/defence"
            className="group flex items-center gap-2.5 rounded-full border border-cyan-400/60 bg-cyan-500/20 px-7 py-3.5 text-xs sm:text-sm font-bold uppercase tracking-wider text-cyan-200 backdrop-blur-md transition-all duration-300 hover:scale-105 hover:bg-cyan-500 hover:text-black hover:shadow-[0_0_30px_rgba(0,229,255,0.6)]"
          >
            <Shield className="h-4 w-4 text-cyan-400 group-hover:text-black" />
            Explore Defence
            <ArrowRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" />
          </Link>

          <Link
            to="/agriculture"
            className="group flex items-center gap-2.5 rounded-full border border-emerald-400/60 bg-emerald-500/20 px-7 py-3.5 text-xs sm:text-sm font-bold uppercase tracking-wider text-emerald-200 backdrop-blur-md transition-all duration-300 hover:scale-105 hover:bg-emerald-500 hover:text-black hover:shadow-[0_0_30px_rgba(16,185,129,0.6)]"
          >
            <Sprout className="h-4 w-4 text-emerald-400 group-hover:text-black" />
            Explore Agriculture
            <ArrowRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" />
          </Link>

          <button
            onClick={() => onOpenShowcase && onOpenShowcase('aegis-mk4')}
            className="flex items-center gap-2 rounded-full border border-white/20 bg-white/5 px-6 py-3.5 text-xs sm:text-sm font-semibold uppercase tracking-wider text-white backdrop-blur transition-all duration-300 hover:border-white/50 hover:bg-white/15"
          >
            <Sparkles className="h-4 w-4 text-cyan-300" />
            Cinematic Showcase
          </button>
        </motion.div>

        {/* Live System Capabilities Bar */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.85 }}
          className="mt-14 grid w-full max-w-4xl grid-cols-2 gap-3 sm:grid-cols-4 border-t border-white/10 pt-6 text-left"
        >
          <div className="border-l border-cyan-500/40 pl-4">
            <span className="font-display text-2xl sm:text-3xl font-extrabold text-white">55 MIN</span>
            <p className="text-[11px] uppercase tracking-wider text-white/50">Max Flight Endurance</p>
          </div>
          <div className="border-l border-cyan-500/40 pl-4">
            <span className="font-display text-2xl sm:text-3xl font-extrabold text-white">25 KM</span>
            <p className="text-[11px] uppercase tracking-wider text-white/50">Encrypted C2 Range</p>
          </div>
          <div className="border-l border-emerald-500/40 pl-4">
            <span className="font-display text-2xl sm:text-3xl font-extrabold text-white">40 LITER</span>
            <p className="text-[11px] uppercase tracking-wider text-white/50">Precision Spray Tank</p>
          </div>
          <div className="border-l border-emerald-500/40 pl-4">
            <span className="font-display text-2xl sm:text-3xl font-extrabold text-white">LEVEL 8</span>
            <p className="text-[11px] uppercase tracking-wider text-white/50">Wind Resistance (19 m/s)</p>
          </div>
        </motion.div>
      </motion.div>

      {/* Downward Scroll Indicator */}
      <a
        href="#sectors"
        className="mx-auto mt-10 flex flex-col items-center gap-2 text-[10px] uppercase tracking-[0.3em] text-white/50 transition hover:text-white"
        aria-label="Scroll to exploration sections"
      >
        <span>Discover Sectors</span>
        <ChevronDown className="h-4 w-4 animate-bounce text-cyan-400" />
      </a>
    </section>
  );
}
