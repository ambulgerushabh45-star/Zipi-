import { motion } from 'framer-motion';
import { ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import { CATEGORY_LABELS, PRODUCTS, getProduct, type Category } from '@/data/products';
import SectionHeading from '@/components/common/SectionHeading';

const CATEGORY_IMAGE_SOURCE: Record<Category, string> = {
  defence: 'aegis-mk4',
  agriculture: 'terra-spray-x40',
  commercial: 'apex-pro',
  camera: 'horizon-ultra',
  mini: 'nano-mini',
  fpv: 'storm-fpv',
  beginner: 'scout-starter',
  accessories: 'power-hub',
};

const CATEGORY_TAGLINE: Record<Category, string> = {
  defence: 'Tactical ISR, perimeter security & search and rescue',
  agriculture: 'Heavy-payload 40L sprayers & multispectral NDVI mapping',
  commercial: 'Industrial infrastructure audits & 5.4K cinema rigs',
  camera: 'Stabilized 4K and 48MP imaging in the sky',
  mini: 'Sub-250 g ultralights for effortless everyday flight',
  fpv: 'Immersive low-latency digital racing quadcopters',
  beginner: 'Guided telemetry, optical flow & safe training',
  accessories: 'Smart chargers, high-efficiency blades & battery hubs',
};

const CATEGORY_ORDER: Category[] = [
  'defence',
  'agriculture',
  'commercial',
  'camera',
  'fpv',
  'accessories',
];

export default function ExploreCategories({ showHeading = true }: { showHeading?: boolean }) {
  return (
    <section id="categories" className="mx-auto max-w-7xl scroll-mt-24 px-5 py-24 sm:px-8">
      {showHeading && (
        <SectionHeading
          eyebrow="Specialized Categories"
          title={<>Engineered for <span className="text-cyan-400">Every Sky.</span></>}
          description="From sovereign tactical security to high-acreage agricultural spraying, discover the exact unmanned architecture built for your operation."
        />
      )}
      <div className={`grid gap-6 sm:grid-cols-2 lg:grid-cols-3 ${showHeading ? 'mt-14' : ''}`}>
        {CATEGORY_ORDER.map((category, i) => {
          const source = getProduct(CATEGORY_IMAGE_SOURCE[category]) || PRODUCTS[0];
          const count = PRODUCTS.filter((p) => p.category === category).length;
          const targetUrl =
            category === 'defence'
              ? '/defence'
              : category === 'agriculture'
              ? '/agriculture'
              : `/products?category=${category}`;

          return (
            <motion.div
              key={category}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-60px' }}
              transition={{ duration: 0.6, delay: i * 0.08, ease: [0.22, 1, 0.36, 1] }}
            >
              <Link
                to={targetUrl}
                className="group relative block aspect-[4/3] sm:aspect-[4/5] overflow-hidden rounded-3xl bg-neutral-900 border border-white/10 shadow-2xl transition-all duration-500 hover:border-cyan-400/50 hover:shadow-[0_0_35px_rgba(0,229,255,0.18)]"
              >
                {source && (
                  <img
                    src={source.image}
                    alt={CATEGORY_LABELS[category]}
                    loading="lazy"
                    className="absolute inset-0 h-full w-full object-cover opacity-70 transition-transform duration-1000 ease-out group-hover:scale-110 group-hover:opacity-90"
                  />
                )}
                <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent" />
                <div className="absolute inset-x-0 bottom-0 flex flex-col gap-2 p-6 sm:p-7 text-white">
                  <p className="text-xs font-mono font-bold uppercase tracking-[0.2em] text-cyan-400">
                    {count} Available Systems
                  </p>
                  <h3 className="flex items-center justify-between font-display text-2xl font-bold">
                    {CATEGORY_LABELS[category]}
                    <ArrowRight className="h-5 w-5 -translate-x-2 opacity-0 transition-all duration-300 group-hover:translate-x-0 group-hover:opacity-100 text-cyan-400" />
                  </h3>
                  <p className="text-xs sm:text-sm text-zinc-300 opacity-90 line-clamp-2">
                    {CATEGORY_TAGLINE[category]}
                  </p>
                </div>
              </Link>
            </motion.div>
          );
        })}
      </div>
    </section>
  );
}
