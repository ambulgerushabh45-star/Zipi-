export type Category =
  | 'defence'
  | 'agriculture'
  | 'commercial'
  | 'camera'
  | 'mini'
  | 'fpv'
  | 'beginner'
  | 'accessories';

export type FeatureQuadrant = {
  id: 'payload' | 'stabilization' | 'quality' | 'control';
  title: string;
  shortDesc: string;
  detail: string;
  metric: string;
  metricLabel: string;
};

export type Product = {
  id: string;
  name: string;
  category: Category;
  subCategory?: string;
  tagline: string;
  description: string;
  price: number;
  originalPrice?: number;
  rating: number;
  reviewCount: number;
  image: string;
  gallery: string[];
  colors: { name: string; hex: string }[];
  badge?: 'New' | 'Best Seller' | 'Sale' | 'Military-Grade' | 'High-Capacity';
  specs: {
    camera: string;
    battery: string;
    range: string;
    maxSpeed: string;
    weight: string;
    flightTime: string;
    payloadCapacity?: string;
    windResistance?: string;
    operationalCeiling?: string;
    encryption?: string;
  };
  highlights: string[];
  showcaseFeatures: {
    shooting: FeatureQuadrant;
    stabilization: FeatureQuadrant;
    quality: FeatureQuadrant;
    control: FeatureQuadrant;
  };
};

export const CATEGORY_LABELS: Record<Category, string> = {
  defence: 'Defence & Security',
  agriculture: 'Agriculture & Farming',
  commercial: 'Commercial & Industrial',
  camera: 'Camera Drones',
  mini: 'Mini & Ultralight',
  fpv: 'FPV Racing',
  beginner: 'Beginner & Training',
  accessories: 'Accessories & Systems',
};

const px = (id: string) =>
  `https://images.pexels.com/photos/${id}/pexels-photo-${id}.jpeg?auto=compress&cs=tinysrgb&w=1400`;

export const PRODUCTS: Product[] = [
  // ==========================================
  // DEFENCE & TACTICAL SYSTEMS
  // ==========================================
  {
    id: 'aegis-mk4',
    name: 'ZIPI Aegis Sentinel MK-IV',
    category: 'defence',
    subCategory: 'Surveillance Drones',
    tagline: 'Tactical autonomous long-range reconnaissance and ISR platform.',
    description:
      'Engineered for perimeter defense, strategic reconnaissance, and critical asset protection. The Aegis Sentinel MK-IV combines a dual radiometric thermal/optical turret with an AES-256 encrypted C2 link for uncompromised tactical observation in day, night, and severe atmospheric interference.',
    price: 14500,
    rating: 4.98,
    reviewCount: 42,
    image: px('17854251'),
    gallery: [px('17854251'), px('6493443'), px('19117243')],
    colors: [
      { name: 'Tactical Matte Black', hex: '#111315' },
      { name: 'Stealth Olive Drab', hex: '#2b3327' },
      { name: 'Desert Tan', hex: '#635b4b' },
    ],
    badge: 'Military-Grade',
    specs: {
      camera: 'Dual Radiometric FLIR 640x512 + 4K 40x Optical Zoom',
      battery: '16,000 mAh Dual-Redundant LiPo',
      range: '25 km Line-of-Sight',
      maxSpeed: '92 km/h',
      weight: '3.85 kg',
      flightTime: '55 min',
      payloadCapacity: '2.5 kg',
      windResistance: 'Level 8 (18.5 m/s)',
      operationalCeiling: '6,500 m MSL',
      encryption: 'AES-256 Frequency-Hopping',
    },
    highlights: [
      'Dual Thermal & 40x Optical EO/IR Turret',
      'AES-256 Encrypted Frequency-Hopping Link',
      'Autonomous Waypoint & Perimeter Patrol Suite',
      'Level 8 High-Gust Wind Resistance',
    ],
    showcaseFeatures: {
      shooting: {
        id: 'payload',
        title: 'Shooting Functions',
        shortDesc: 'Dual FLIR Thermal & 40x Optical EO Turret',
        detail:
          'Continuous 40x optical zoom with simultaneous 640x512 radiometric thermal imaging. Detects human-sized thermal signatures at 2.4 km in zero daylight.',
        metric: '40x / 640x512',
        metricLabel: 'Optical Zoom & Thermal',
      },
      stabilization: {
        id: 'stabilization',
        title: 'Advanced Stabilization',
        shortDesc: 'Triple-Redundant IMU with 0.005° Gimbal Precision',
        detail:
          'Brushless magnetic-encoder 3-axis gimbal with active gyro-stabilized horizon lock ensures motionless video feeds during evasive maneuvers and heavy gusts.',
        metric: '±0.005°',
        metricLabel: 'Gimbal Precision',
      },
      quality: {
        id: 'quality',
        title: 'Premium Quality',
        shortDesc: 'Toray T800 Carbon-Kevlar Monocoque IP65',
        detail:
          'Ruggedized aerospace monocoque chassis withstands extreme ambient temperatures (-20°C to +55°C) and pressurized water spray with IP65 weatherproofing.',
        metric: 'IP65',
        metricLabel: 'Weather Protection',
      },
      control: {
        id: 'control',
        title: 'Remote Control',
        shortDesc: '25 km Frequency-Hopping Telemetry',
        detail:
          'Tactical ground control station with dual high-brightness 2000-nit screens, multi-constellation GNSS anti-jamming, and encrypted relay handoff capability.',
        metric: '25 km',
        metricLabel: 'Secure Link Range',
      },
    },
  },
  {
    id: 'recon-raven',
    name: 'ZIPI Recon Raven V2',
    category: 'defence',
    subCategory: 'Reconnaissance Drones',
    tagline: 'Ultra-silent stealth perimeter & border surveillance quadcopter.',
    description:
      'Designed for silent tactical reconnaissance and covert border observation. Operating at less than 38 dB at 50 meters altitude, the Recon Raven V2 delivers persistent Starlight night vision and micro-radar terrain navigation with zero acoustic footprint.',
    price: 8900,
    rating: 4.95,
    reviewCount: 38,
    image: px('6145874'),
    gallery: [px('6145874'), px('17854251'), px('4141070')],
    colors: [
      { name: 'Radar-Absorbing Charcoal', hex: '#16191d' },
      { name: 'Night Urban Camo', hex: '#262d35' },
    ],
    badge: 'New',
    specs: {
      camera: 'Starlight Ultra-Low-Light 4K Sensor + IR Laser',
      battery: '12,500 mAh Smart Flight Pack',
      range: '18 km',
      maxSpeed: '78 km/h',
      weight: '2.15 kg',
      flightTime: '48 min',
      payloadCapacity: '1.2 kg',
      windResistance: 'Level 7 (15 m/s)',
      operationalCeiling: '5,000 m MSL',
      encryption: 'AES-128 / Dynamic Frequency Shift',
    },
    highlights: [
      'Acoustic Signature < 38 dB at 50 m',
      'Ultra-Low-Light Starlight 4K Sensor',
      'GPS-Denied Inertial Navigation System',
      'Rapid Deploy Under 45 Seconds',
    ],
    showcaseFeatures: {
      shooting: {
        id: 'payload',
        title: 'Shooting Functions',
        shortDesc: 'Starlight 4K Night Vision Sensor',
        detail:
          'Full-color observation in 0.001 Lux starlight conditions. Features an eye-safe IR illuminator for identifying subjects in pitch-black interiors or ravines.',
        metric: '0.001 Lux',
        metricLabel: 'Sensitivity',
      },
      stabilization: {
        id: 'stabilization',
        title: 'Advanced Stabilization',
        shortDesc: 'Acoustic-Dampened Quiet-Thrust Stabilization',
        detail:
          'Serrated blade aerodynamic wingtips and rubber-isolated motor mounts suppress both airframe oscillation and acoustic vibration harmonics.',
        metric: '< 38 dB',
        metricLabel: 'Acoustic Profile',
      },
      quality: {
        id: 'quality',
        title: 'Premium Quality',
        shortDesc: 'Matte Radar-Absorbing Composite Shell',
        detail:
          'Non-reflective matte composite body absorbs incident radar beams while lightweight structural ribs survive rapid tactical field handling.',
        metric: '2.15 kg',
        metricLabel: 'Carry Weight',
      },
      control: {
        id: 'control',
        title: 'Remote Control',
        shortDesc: 'Inertial Nav + Anti-Spoofing C2 Link',
        detail:
          'Seamless fallback to optical flow and internal IMU dead-reckoning when satellite GPS signals are contested or deliberately jammed.',
        metric: 'Zero-GPS',
        metricLabel: 'Drift Navigation',
      },
    },
  },
  {
    id: 'guardian-sentry',
    name: 'ZIPI Guardian Sentry-X',
    category: 'defence',
    subCategory: 'Security Monitoring Drones',
    tagline: 'Continuous perimeter security & anti-intruder monitoring hexacopter.',
    description:
      'Built for round-the-clock automated security over high-value infrastructure, airports, and military installations. Compatible with autonomous charging hangars, the Sentry-X flies scheduled perimeter tracks with AI target classification and motor redundancy.',
    price: 12200,
    rating: 4.92,
    reviewCount: 29,
    image: px('6493443'),
    gallery: [px('6493443'), px('17854251')],
    colors: [
      { name: 'Industrial Graphite', hex: '#1c2024' },
      { name: 'Safety Hi-Viz White', hex: '#e9ecef' },
    ],
    badge: 'Best Seller',
    specs: {
      camera: '360° Rotating Dual-Lens Optical/Thermal Hub',
      battery: 'Dual 14,000 mAh Hot-Swap Packs',
      range: '20 km Autonomous Perimeter',
      maxSpeed: '82 km/h',
      weight: '4.2 kg',
      flightTime: '50 min',
      payloadCapacity: '3.0 kg',
      windResistance: 'Level 8 (18 m/s)',
      operationalCeiling: '5,500 m MSL',
      encryption: 'TLS 1.3 / AES-256',
    },
    highlights: [
      'Autonomous Drone-in-a-Box Compatible',
      'One-Motor-Out Flight Safety Redundancy',
      'Edge AI Vehicle & Human Detection',
      'Continuous 24/7 Automated Rotation',
    ],
    showcaseFeatures: {
      shooting: {
        id: 'payload',
        title: 'Shooting Functions',
        shortDesc: 'Edge-AI Perimeter Threat Classifier',
        detail:
          'Neural network computer vision recognizes vehicle types, fence breaches, and unauthorized personnel in real time with 99.4% classification accuracy.',
        metric: '99.4%',
        metricLabel: 'Detection Accuracy',
      },
      stabilization: {
        id: 'stabilization',
        title: 'Advanced Stabilization',
        shortDesc: 'Hex-Rotor Thrust Redundancy Vectoring',
        detail:
          'Hexacopter architecture allows safe controlled flight and automated return-to-base even if one entire motor or propeller suffers catastrophic failure.',
        metric: '6-Rotor',
        metricLabel: 'Fault Tolerance',
      },
      quality: {
        id: 'quality',
        title: 'Premium Quality',
        shortDesc: 'Magnesium Alloy Core & Sealed Motors',
        detail:
          'Precision CNC-machined magnesium skeleton keeps center of mass centered over the optical payload while brushless motors are sealed against desert dust.',
        metric: '10,000 hrs',
        metricLabel: 'MTBF Rating',
      },
      control: {
        id: 'control',
        title: 'Remote Control',
        shortDesc: 'Automated Docking Station Interface',
        detail:
          'Seamless automatic landing with precision RTK ground beacons into enclosed climate-controlled charging docks for continuous hands-free operation.',
        metric: '< 2 cm',
        metricLabel: 'Dock Landing Error',
      },
    },
  },
  {
    id: 'valkyrie-sar',
    name: 'ZIPI Valkyrie SAR-9',
    category: 'defence',
    subCategory: 'Search and Rescue Drones',
    tagline: 'Rapid-response search, rescue and disaster observation hexacopter.',
    description:
      'Purpose-built for humanitarian aid, mountainous search and rescue, and coastal maritime distress tracking. Features a 12,000-lumen dual searchlight, an emergency rescue drop winch, and all-weather torrential rain tolerance.',
    price: 10800,
    originalPrice: 11900,
    rating: 4.97,
    reviewCount: 34,
    image: px('5555813'),
    gallery: [px('5555813'), px('17854251'), px('6493443')],
    colors: [
      { name: 'Rescue Signal Orange', hex: '#e65100' },
      { name: 'Arctic Visibility White', hex: '#f8fafc' },
    ],
    badge: 'Sale',
    specs: {
      camera: 'Thermal Survivor Detection Pod + 4K Low-Light',
      battery: '15,500 mAh Weather-Insulated LiPo',
      range: '16 km',
      maxSpeed: '85 km/h',
      weight: '4.6 kg',
      flightTime: '45 min',
      payloadCapacity: '3.5 kg Emergency Winch Drop',
      windResistance: 'Level 8 (19 m/s Gale)',
      operationalCeiling: '6,200 m High-Altitude Rescue',
      encryption: 'Encrypted Emergency Transponder',
    },
    highlights: [
      '12,000-Lumen High-Intensity Dual Searchlight',
      'Motorized First-Aid / Radio Winch Release',
      'Submersible IP66 Marine-Weather Proofing',
      'High-Altitude Alpine Propeller Tuning',
    ],
    showcaseFeatures: {
      shooting: {
        id: 'payload',
        title: 'Shooting Functions',
        shortDesc: '12,000-Lumen Searchlight & Thermal Spotter',
        detail:
          'Synchronized motorized searchlight tracks gimbal orientation to illuminate dark valleys and maritime waves, guiding rescue helicopters to survivors.',
        metric: '12,000 lm',
        metricLabel: 'Illumination',
      },
      stabilization: {
        id: 'stabilization',
        title: 'Advanced Stabilization',
        shortDesc: 'High-Alpine Dynamic Wind Resistance',
        detail:
          'Tuned for high altitude thin air and sudden mountain downdrafts with oversized high-pitch carbon propellers and rapid throttle response.',
        metric: '19 m/s',
        metricLabel: 'Gust Capability',
      },
      quality: {
        id: 'quality',
        title: 'Premium Quality',
        shortDesc: 'Marine-Grade IP66 Torrential Rain Enclosure',
        detail:
          'Sealed hydrophobic breathing membranes prevent fogging and salt corrosion, operating flawlessly in driving rain and maritime snowstorms.',
        metric: 'IP66',
        metricLabel: 'Marine Protection',
      },
      control: {
        id: 'control',
        title: 'Remote Control',
        shortDesc: 'Emergency Winch & Life-Line Drop',
        detail:
          'Precision remote-controlled 30-meter cable drop delivers automated defibrillators, radios, or survival blankets directly to trapped mountaineers.',
        metric: '3.5 kg',
        metricLabel: 'Drop Capacity',
      },
    },
  },

  // ==========================================
  // AGRICULTURE & PRECISION FARMING
  // ==========================================
  {
    id: 'terra-spray-x40',
    name: 'ZIPI Terra Spray X40',
    category: 'agriculture',
    subCategory: 'Agricultural Spraying Drones',
    tagline: 'High-capacity autonomous agricultural spraying and seeding drone.',
    description:
      'The flagship of modern precision agriculture. With a massive 40-liter quick-release liquid tank and 16-nozzle centrifugal atomization system, the Terra Spray X40 covers up to 45 acres per hour with millimeter-accurate droplet control and zero overspray.',
    price: 16800,
    rating: 4.96,
    reviewCount: 56,
    image: px('34182367'),
    gallery: [px('34182367'), px('6493443'), px('19117243')],
    colors: [
      { name: 'Agri Cyber Green', hex: '#10b981' },
      { name: 'Harvest White', hex: '#f8fafc' },
    ],
    badge: 'High-Capacity',
    specs: {
      camera: 'FPV Ultra-Wide Dual Obstacle Camera + RTK',
      battery: '30,000 mAh Ultra-Fast 9-Min Charge Battery',
      range: '10 km Field Coverage',
      maxSpeed: '42 km/h (Operational Spray 25 km/h)',
      weight: '28 kg (Dry) / 68 kg (Full Payload)',
      flightTime: '24 min (Full 40L) / 42 min (Empty)',
      payloadCapacity: '40 L Liquid / 50 kg Solid Granules',
      windResistance: 'Level 6 (12 m/s)',
      operationalCeiling: '3,000 m MSL',
      encryption: 'Field-Link RTK Protocol',
    },
    highlights: [
      '40-Liter Tank with Centrifugal Atomizers',
      'Covers 45 Acres Per Hour Spray Efficiency',
      'Dual Spherical Millimeter-Wave Radars',
      '1-Centimeter RTK Boundary Precision',
    ],
    showcaseFeatures: {
      shooting: {
        id: 'payload',
        title: 'Shooting Functions',
        shortDesc: '16-Nozzle Centrifugal Atomizing Spray Bar',
        detail:
          'Proprietary magnetic pumps with adjustable droplet size (50 to 500 microns) produce uniform downward penetration under dense fruit and crop canopies.',
        metric: '12 L/min',
        metricLabel: 'Max Spray Flow',
      },
      stabilization: {
        id: 'stabilization',
        title: 'Advanced Stabilization',
        shortDesc: 'Liquid Slosh Compensation Algorithm',
        detail:
          'Dynamic multi-axis center of gravity sensors adjust motor thrust in real time as liquid shifts during tight turnarounds at crop headlands.',
        metric: 'Real-Time',
        metricLabel: 'Inertia Balance',
      },
      quality: {
        id: 'quality',
        title: 'Premium Quality',
        shortDesc: 'Full IP67 Washdown & Chemical Proofing',
        detail:
          'Constructed from anti-corrosive carbon fiber and high-density polyethylene. The entire aircraft can be hose-washed with pressurized water after chemical use.',
        metric: 'IP67',
        metricLabel: 'Washable Rating',
      },
      control: {
        id: 'control',
        title: 'Remote Control',
        shortDesc: 'RTK Sub-Centimeter Field Boundary Mapping',
        detail:
          'Autonomous boundary flight planning software generates optimal flight tracks around obstacles, power lines, and tree boundaries automatically.',
        metric: '1 cm',
        metricLabel: 'Boundary Precision',
      },
    },
  },
  {
    id: 'agriscan-ndvi',
    name: 'ZIPI Agriscan NDVI Pro',
    category: 'agriculture',
    subCategory: 'Crop Monitoring Drones',
    tagline: 'Multispectral crop stress analysis and precision prescription mapping.',
    description:
      'Detect crop disease, moisture stress, and nitrogen deficiencies before they become visible to the human eye. The Agriscan NDVI Pro pairs a 5-band multispectral sensor with a real-time downwelling light sensor to produce calibrated scientific vegetative maps.',
    price: 6400,
    rating: 4.89,
    reviewCount: 48,
    image: px('2044043'),
    gallery: [px('2044043'), px('34182367')],
    colors: [
      { name: 'Field Emerald', hex: '#059669' },
      { name: 'Solar White', hex: '#f9fafb' },
    ],
    badge: 'Best Seller',
    specs: {
      camera: '5-Band Multispectral (RGB, Red, Green, RedEdge, NIR)',
      battery: '14,000 mAh High-Density LiPo',
      range: '15 km',
      maxSpeed: '65 km/h',
      weight: '2.4 kg',
      flightTime: '44 min',
      payloadCapacity: '1.5 kg',
      windResistance: 'Level 7 (14 m/s)',
      operationalCeiling: '4,500 m MSL',
      encryption: 'Encrypted Telemetry Cloud Sync',
    },
    highlights: [
      '5-Band Multispectral Radiometric Sensor',
      'Real-Time Downwelling Sunshine Irradiance Sensor',
      'Generates Instant NDVI, NDRE, SAVI Crop Indices',
      'Covers 150 Acres in a Single 40-Min Flight',
    ],
    showcaseFeatures: {
      shooting: {
        id: 'payload',
        title: 'Shooting Functions',
        shortDesc: '5-Band Multispectral Imaging Suite',
        detail:
          'Captures synchronized Red, Green, Blue, RedEdge, and Near-Infrared spectra with global shutters to pinpoint chlorosis and fungal outbreaks weeks early.',
        metric: '5-Band',
        metricLabel: 'Multispectral Array',
      },
      stabilization: {
        id: 'stabilization',
        title: 'Advanced Stabilization',
        shortDesc: 'Nadir-Locked Gyro Gimbal with RTK Tagging',
        detail:
          'Every frame is geotagged with 1.5 cm accuracy using RTK coordinates while the nadir gimbal keeps camera angle exactly perpendicular to ground slope.',
        metric: '1.5 cm',
        metricLabel: 'Geotag Accuracy',
      },
      quality: {
        id: 'quality',
        title: 'Premium Quality',
        shortDesc: 'Aerospace-Grade Featherweight Monocoque',
        detail:
          'Ultralight Toray carbon-fiber arms maximize flight endurance, enabling continuous large-acreage farm coverage without frequent battery stops.',
        metric: '44 min',
        metricLabel: 'Endurance',
      },
      control: {
        id: 'control',
        title: 'Remote Control',
        shortDesc: 'Variable-Rate Prescription Map Export',
        detail:
          'Exports standardized shapefiles and ISO-XML files directly to modern tractor terminals and ZIPI spray drones for precision spot-treatment.',
        metric: 'ISO-XML',
        metricLabel: 'Tractor Compatible',
      },
    },
  },
  {
    id: 'fieldmapper-aero',
    name: 'ZIPI FieldMapper Aero-T',
    category: 'agriculture',
    subCategory: 'Field Mapping Drones',
    tagline: 'Topographical field mapping and high-acreage orthomosaic UAV.',
    description:
      'Equipped with a 61-megapixel full-frame photogrammetry sensor and mechanical leaf shutter, the FieldMapper Aero-T maps 250 acres per flight. Creates survey-grade 3D elevation contour models and volumetric drainage analyses for agricultural engineering.',
    price: 7900,
    rating: 4.91,
    reviewCount: 31,
    image: px('5555813'),
    gallery: [px('5555813'), px('2044043')],
    colors: [
      { name: 'Survey Carbon', hex: '#1f2937' },
      { name: 'Titanium Grey', hex: '#6b7280' },
    ],
    badge: 'New',
    specs: {
      camera: '61MP Full-Frame Mechanical Shutter (0.7s Interval)',
      battery: '16,000 mAh Dual Smart Pack',
      range: '18 km',
      maxSpeed: '72 km/h',
      weight: '3.1 kg',
      flightTime: '46 min',
      payloadCapacity: '2.0 kg',
      windResistance: 'Level 7 (15 m/s)',
      operationalCeiling: '5,000 m MSL',
      encryption: 'Encrypted GeoTIFF Storage',
    },
    highlights: [
      '61MP Full-Frame Mechanical Shutter',
      'Ground Sampling Distance 1.1 cm/pixel',
      'Automated 3D Terrain-Following Elevation',
      'Direct PPK/RTK Base Station Synchronization',
    ],
    showcaseFeatures: {
      shooting: {
        id: 'payload',
        title: 'Shooting Functions',
        shortDesc: '61MP Full-Frame Photogrammetry Shutter',
        detail:
          'Mechanical leaf shutter eliminates rolling shutter distortion at high flight speeds, producing razor-sharp orthomosaics with 1.1 cm/px GSD.',
        metric: '61 MP',
        metricLabel: 'Full-Frame Sensor',
      },
      stabilization: {
        id: 'stabilization',
        title: 'Advanced Stabilization',
        shortDesc: 'Terrain-Following LIDAR Radar',
        detail:
          'Downward high-frequency millimeter-wave radar continuously adjusts flight altitude above rolling hill contours to preserve constant ground resolution.',
        metric: '1.1 cm/px',
        metricLabel: 'Ground Resolution',
      },
      quality: {
        id: 'quality',
        title: 'Premium Quality',
        shortDesc: 'Quick-Deploy Foldable Carbon Airframe',
        detail:
          'Folds down into a rugged Pelican field case within 30 seconds for quick transport between remote agricultural plots.',
        metric: '30 sec',
        metricLabel: 'Pack-down Time',
      },
      control: {
        id: 'control',
        title: 'Remote Control',
        shortDesc: 'Orthomosaic Mission Planning App',
        detail:
          'Calculates crosswind crab angles, overlap ratios (up to 85%), and optimal sun-angle flight lines for shadow-free crop cartography.',
        metric: '250 acres',
        metricLabel: 'Per Battery Set',
      },
    },
  },
  {
    id: 'cropguard-harvest',
    name: 'ZIPI CropGuard Harvest-8',
    category: 'agriculture',
    subCategory: 'Precision Farming Solutions',
    tagline: 'All-weather autonomous orchard & steep-slope canopy protection hexacopter.',
    description:
      'Engineered specifically for steep-slope mountain vineyards, citrus orchards, and tall fruit trees. The Harvest-8 utilizes dual high-velocity downdraft blowers to roll fruit tree leaves and deliver organic protection deep into dense tree canopies.',
    price: 13500,
    rating: 4.94,
    reviewCount: 27,
    image: px('6493443'),
    gallery: [px('6493443'), px('34182367')],
    colors: [
      { name: 'Forest Green', hex: '#064e3b' },
      { name: 'Safety Yellow', hex: '#ca8a04' },
    ],
    specs: {
      camera: 'Stereo Vision 3D Orchard Mapping Camera',
      battery: '26,000 mAh Heavy-Duty Swappable Pack',
      range: '12 km',
      maxSpeed: '45 km/h',
      weight: '21 kg (Dry) / 48 kg (Max Payload)',
      flightTime: '28 min (Full Payload)',
      payloadCapacity: '25 L High-Pressure Liquid Tank',
      windResistance: 'Level 7 (15 m/s)',
      operationalCeiling: '3,800 m Steep Mountain Slopes',
      encryption: 'Field-Link Encrypted Telemetry',
    },
    highlights: [
      'Twin Air-Assisted Downdraft Leaf-Turning Blowers',
      'Steep Slope Terrain Radar up to 45° Mountain Orchards',
      '360° Spherical Branch & Obstacle Swerve',
      '25-Liter High-Pressure Brass Swivel Nozzles',
    ],
    showcaseFeatures: {
      shooting: {
        id: 'payload',
        title: 'Shooting Functions',
        shortDesc: 'Down-Draft Air-Assisted Orchard Nozzles',
        detail:
          'High-velocity downward air blast separates dense foliage, ensuring both the top and underside of fruit tree leaves receive uniform organic protection.',
        metric: '25 L',
        metricLabel: 'Tank Volume',
      },
      stabilization: {
        id: 'stabilization',
        title: 'Advanced Stabilization',
        shortDesc: '45° Mountain Orchard Slope Tracking',
        detail:
          'Dynamic multi-beam radar follows steep vineyard terraces up to 45 degrees inclination with automatic distance hold at 2.5 meters above canopy.',
        metric: '45°',
        metricLabel: 'Slope Capability',
      },
      quality: {
        id: 'quality',
        title: 'Premium Quality',
        shortDesc: 'Corrosion-Resistant Brass & Stainless Fixtures',
        detail:
          'All spray plumbing and structural joints are fabricated from chemical-grade 316 stainless steel and anti-corrosive brass.',
        metric: '316 SS',
        metricLabel: 'Wetted Materials',
      },
      control: {
        id: 'control',
        title: 'Remote Control',
        shortDesc: 'Tree-Canopy 3D Vector Flight Planning',
        detail:
          'Identifies individual tree positions using stereo vision and navigates around branches while keeping spray targeted strictly onto foliage.',
        metric: '3D Vector',
        metricLabel: 'Branch Avoidance',
      },
    },
  },

  // ==========================================
  // COMMERCIAL & INDUSTRIAL AIRCRAFT
  // ==========================================
  {
    id: 'apex-pro',
    name: 'ZIPI Apex Pro',
    category: 'commercial',
    subCategory: 'Industrial Drones',
    tagline: 'Cinema-grade flight and structural inspection platform.',
    description:
      'The Apex Pro pairs a 1-inch sensor with a three-axis gimbal and an intelligent flight stack built for industrial inspection, high-voltage utility audits, and cinema mapping. Its hexacopter frame keeps the aircraft rock steady in gusts up to 35 km/h.',
    price: 2199,
    rating: 4.9,
    reviewCount: 214,
    image: px('6493443'),
    gallery: [px('6493443'), px('34182337'), px('5555813')],
    colors: [
      { name: 'Glacier White', hex: '#f4f6f8' },
      { name: 'Graphite', hex: '#2b2f36' },
    ],
    badge: 'Best Seller',
    specs: {
      camera: '1-inch 20MP, 5.4K/60fps Cinema Sensor',
      battery: '6,000 mAh Smart Flight Battery',
      range: '15 km',
      maxSpeed: '72 km/h',
      weight: '1.1 kg',
      flightTime: '42 min',
      payloadCapacity: '800 g',
      windResistance: 'Level 6 (12 m/s)',
      operationalCeiling: '5,000 m MSL',
      encryption: 'OcuSync Enterprise Encryption',
    },
    highlights: [
      'Omnidirectional Obstacle Sensing Matrix',
      'Hexacopter Airframe Redundancy',
      'Automated Industrial Waypoint Suite',
      'Cinema-Grade 5.4K/60fps Recording',
    ],
    showcaseFeatures: {
      shooting: {
        id: 'payload',
        title: 'Shooting Functions',
        shortDesc: '1-inch 20MP 5.4K Cinema Sensor',
        detail:
          'Flagship 1-inch CMOS sensor with 12.6 stops of dynamic range captures crisp structural details on wind turbines, bridges, and solar arrays.',
        metric: '5.4K/60p',
        metricLabel: 'Video Fidelity',
      },
      stabilization: {
        id: 'stabilization',
        title: 'Advanced Stabilization',
        shortDesc: '3-Axis Mechanical Gimbal with Horizon Lock',
        detail:
          'Eliminates roll and vibration even during sudden crosswinds, yielding buttery-smooth inspection panos and cinematic master shots.',
        metric: '±0.008°',
        metricLabel: 'Stabilization Error',
      },
      quality: {
        id: 'quality',
        title: 'Premium Quality',
        shortDesc: 'Toray High-Modulus Carbon Fiber Arm Booms',
        detail:
          'Rigid carbon arms with aluminum joint clamps withstand continuous industrial deployment cycles without flexing.',
        metric: '1.1 kg',
        metricLabel: 'Airframe Mass',
      },
      control: {
        id: 'control',
        title: 'Remote Control',
        shortDesc: '15 km Low-Latency Triple-Antenna Link',
        detail:
          'Transmit full 1080p 60fps video feeds to dual pilot and camera operator controllers with sub-35ms latency.',
        metric: '15 km',
        metricLabel: 'Transmission',
      },
    },
  },
  {
    id: 'horizon-ultra',
    name: 'ZIPI Horizon Ultra',
    category: 'camera',
    subCategory: 'Camera Drones',
    tagline: 'Pro imaging in a foldable carbon frame.',
    description:
      'Horizon Ultra delivers flagship stabilization in a package that folds to the size of a water bottle. Dual-band transmission keeps your feed sharp at long range, while the 48MP 1/1.3-inch sensor records 4K HDR at 120fps.',
    price: 1299,
    originalPrice: 1499,
    rating: 4.8,
    reviewCount: 368,
    image: px('5555813'),
    gallery: [px('5555813'), px('2044043'), px('6493443')],
    colors: [
      { name: 'Arctic', hex: '#eef2f6' },
      { name: 'Midnight', hex: '#1d222a' },
    ],
    badge: 'Sale',
    specs: {
      camera: '1/1.3-inch 48MP, 4K/120fps HDR',
      battery: '4,200 mAh High-Density Pack',
      range: '12 km',
      maxSpeed: '68 km/h',
      weight: '640 g',
      flightTime: '38 min',
    },
    highlights: ['3-Axis Mechanical Gimbal', 'Foldable Ultra-Compact Body', 'Dual-Band Transmission'],
    showcaseFeatures: {
      shooting: {
        id: 'payload',
        title: 'Shooting Functions',
        shortDesc: '48MP 4K/120fps Slow-Motion Cinema',
        detail: 'Dual native ISO sensor with HDR video recording at 120 frames per second for ultra-fluid action capture.',
        metric: '4K/120fps',
        metricLabel: 'Slow Motion',
      },
      stabilization: {
        id: 'stabilization',
        title: 'Advanced Stabilization',
        shortDesc: '3-Axis Brushless Gimbal',
        detail: 'Mechanical stabilization dampens air vibration for shake-free vertical and landscape cinematic capture.',
        metric: '3-Axis',
        metricLabel: 'Gimbal Core',
      },
      quality: {
        id: 'quality',
        title: 'Premium Quality',
        shortDesc: 'Precision Magnesium-Carbon Fold Joints',
        detail: 'Rated for over 15,000 fold cycles with tight aerospace tolerances and zero arm wobble.',
        metric: '640 g',
        metricLabel: 'Travel Weight',
      },
      control: {
        id: 'control',
        title: 'Remote Control',
        shortDesc: '12 km Dual-Band OcuSync Link',
        detail: 'Automatic frequency switching between 2.4 GHz and 5.8 GHz ensures crystal-clear HD video stream.',
        metric: '12 km',
        metricLabel: 'Link Range',
      },
    },
  },
  {
    id: 'vista-4k',
    name: 'ZIPI Vista 4K',
    category: 'camera',
    subCategory: 'Camera Drones',
    tagline: 'Golden-hour footage, every flight.',
    description:
      'Vista 4K is the everyday cinematographer’s drone. Its HDR sensor captures wide dynamic range at sunrise and sunset, and ActiveTrack keeps subjects framed automatically.',
    price: 899,
    rating: 4.7,
    reviewCount: 151,
    image: px('2044043'),
    gallery: [px('2044043'), px('175710'), px('7028561')],
    colors: [
      { name: 'Sky Blue', hex: '#8fb4d9' },
      { name: 'Pearl', hex: '#f7f7f5' },
    ],
    specs: {
      camera: '1/2-inch 4K HDR, 60fps',
      battery: '3,500 mAh',
      range: '9 km',
      maxSpeed: '60 km/h',
      weight: '520 g',
      flightTime: '34 min',
    },
    highlights: ['ActiveTrack Subject Lock', 'HDR Video Capture', 'Quick-Share to Phone'],
    showcaseFeatures: {
      shooting: {
        id: 'payload',
        title: 'Shooting Functions',
        shortDesc: 'HDR 4K/60fps Dynamic Range',
        detail: 'Captures vivid highlights and rich shadow details in golden-hour landscapes without blown-out skies.',
        metric: '4K HDR',
        metricLabel: 'Resolution',
      },
      stabilization: {
        id: 'stabilization',
        title: 'Advanced Stabilization',
        shortDesc: 'ActiveTrack 5.0 Auto-Framing',
        detail: 'AI subject tracking locks onto athletes, vehicles, and wildlife while maintaining smooth cinematic orbit.',
        metric: 'AI 5.0',
        metricLabel: 'Tracking Core',
      },
      quality: {
        id: 'quality',
        title: 'Premium Quality',
        shortDesc: 'Impact-Resistant Polycarbonate Shell',
        detail: 'Lightweight aerodynamic housing engineered for everyday aerial adventures.',
        metric: '520 g',
        metricLabel: 'Weight',
      },
      control: {
        id: 'control',
        title: 'Remote Control',
        shortDesc: '9 km Digital Video Feed',
        detail: 'Direct smartphone Wi-Fi 6 download speeds up to 30 MB/s for immediate social media editing.',
        metric: '9 km',
        metricLabel: 'Transmission',
      },
    },
  },
  {
    id: 'nano-mini',
    name: 'ZIPI Nano Mini',
    category: 'mini',
    subCategory: 'Mini Drones',
    tagline: 'Under 249 grams. Over-the-top performance.',
    description:
      'Nano Mini is light enough to skip most national registration rules and tough enough to take a few knocks. Propeller guards and a one-touch return make it a perfect pocket companion.',
    price: 249,
    rating: 4.6,
    reviewCount: 402,
    image: px('175710'),
    gallery: [px('175710'), px('4141070')],
    colors: [
      { name: 'White', hex: '#fafafa' },
      { name: 'Electric Blue', hex: '#0a5cff' },
    ],
    badge: 'New',
    specs: {
      camera: '12MP, 2.7K/30fps',
      battery: '1,800 mAh',
      range: '4 km',
      maxSpeed: '45 km/h',
      weight: '245 g',
      flightTime: '24 min',
    },
    highlights: ['Sub-249 g Design', 'Prop Guards Included', 'One-Touch Return Home'],
    showcaseFeatures: {
      shooting: {
        id: 'payload',
        title: 'Shooting Functions',
        shortDesc: '2.7K Ultra-Clear Quad HD',
        detail: 'Clear 2.7K stabilized video and 12MP photos with quick-shot pre-programmed flight patterns.',
        metric: '2.7K',
        metricLabel: 'Video Output',
      },
      stabilization: {
        id: 'stabilization',
        title: 'Advanced Stabilization',
        shortDesc: 'Downward Optical Flow Positioning',
        detail: 'Maintains rock-steady indoor and outdoor hover without requiring GPS lock.',
        metric: 'Optical',
        metricLabel: 'Hover Sensor',
      },
      quality: {
        id: 'quality',
        title: 'Premium Quality',
        shortDesc: '245g Ultralight Compliance',
        detail: 'Weighs under 250 grams to fly without mandatory pilot registration in most jurisdictions.',
        metric: '245 g',
        metricLabel: 'Gross Mass',
      },
      control: {
        id: 'control',
        title: 'Remote Control',
        shortDesc: 'One-Key Automated Return',
        detail: 'Failsafe automated return-to-home kicks in if battery dips below 15% or signal drops.',
        metric: '4 km',
        metricLabel: 'Controller Range',
      },
    },
  },
  {
    id: 'storm-fpv',
    name: 'ZIPI Storm FPV',
    category: 'fpv',
    subCategory: 'FPV Racing',
    tagline: 'Built for speed. Tuned for the track.',
    description:
      'Storm FPV is a race-ready quad with a 5-inch 3K carbon frame, low-latency digital HD video and precision flight tuning out of the box. Reaches 130 km/h in under 1.8 seconds.',
    price: 599,
    rating: 4.8,
    reviewCount: 96,
    image: px('6145874'),
    gallery: [px('6145874'), px('4141070'), px('3946004')],
    colors: [
      { name: 'Carbon', hex: '#1f2327' },
      { name: 'Signal Blue', hex: '#0a5cff' },
    ],
    specs: {
      camera: 'Low-Latency HD FPV 1080p/120fps (24ms)',
      battery: '6S 1,500 mAh High-C Racing Pack',
      range: '3 km',
      maxSpeed: '130 km/h',
      weight: '690 g',
      flightTime: '8 min High-Thrust',
    },
    highlights: ['5-inch 3K Carbon Frame', 'Sub-24 ms Video Latency', 'Acro & Angle Flight Modes'],
    showcaseFeatures: {
      shooting: {
        id: 'payload',
        title: 'Shooting Functions',
        shortDesc: 'Low-Latency 120fps Digital FPV Feed',
        detail: 'Immersive low-latency digital goggles feed allows millisecond-precise line selection through tight gates.',
        metric: '24 ms',
        metricLabel: 'Video Latency',
      },
      stabilization: {
        id: 'stabilization',
        title: 'Advanced Stabilization',
        shortDesc: 'Betaflight Precision Rate Tuning',
        detail: 'Tuned PID controllers deliver razor-sharp snap rolls, inverted hovers, and high-G diving pullouts.',
        metric: '130 km/h',
        metricLabel: 'Top Speed',
      },
      quality: {
        id: 'quality',
        title: 'Premium Quality',
        shortDesc: '5mm Chamfered 3K Carbon Fiber Arms',
        detail: 'Crash-resistant modular arms can be replaced on the field with two hex bolts in under 2 minutes.',
        metric: '3K Carbon',
        metricLabel: 'Chassis Material',
      },
      control: {
        id: 'control',
        title: 'Remote Control',
        shortDesc: 'ExpressLRS 2.4GHz Control Link',
        detail: 'Ultra-fast 500Hz packet rate provides instantaneous stick-to-motor response with zero lag.',
        metric: '500 Hz',
        metricLabel: 'Packet Rate',
      },
    },
  },
  {
    id: 'power-hub',
    name: 'ZIPI Power Hub Pro',
    category: 'accessories',
    subCategory: 'Charging Stations',
    tagline: 'Multi-battery simultaneous fast-charging station.',
    description:
      'An industrial charging hub with live OLED telemetry that monitors battery internal resistance, cell voltage parity, and charge cycle count. Powers up to three high-capacity drone batteries simultaneously with 200W USB-C GaN delivery.',
    price: 189,
    rating: 4.8,
    reviewCount: 142,
    image: px('3945687'),
    gallery: [px('3945687'), px('19247745')],
    colors: [{ name: 'Anodized Slate', hex: '#2b2f36' }],
    specs: {
      camera: 'Not Applicable',
      battery: 'Powers up to 3 batteries simultaneously (200W)',
      range: 'Not Applicable',
      maxSpeed: 'Not Applicable',
      weight: '420 g',
      flightTime: 'Not Applicable',
    },
    highlights: ['Three-Bay Simultaneous Fast Charge', 'Live Cell Health OLED Display', '200W USB-C GaN Input'],
    showcaseFeatures: {
      shooting: {
        id: 'payload',
        title: 'Shooting Functions',
        shortDesc: 'Battery Telemetry & Diagnostic Interface',
        detail: 'Reads individual LiPo cell health and predicts battery lifecycle degradation.',
        metric: '3-Bay',
        metricLabel: 'Capacity',
      },
      stabilization: {
        id: 'stabilization',
        title: 'Advanced Stabilization',
        shortDesc: 'Active Thermal Current Throttling',
        detail: 'Dual silent ball-bearing fans maintain safe battery temperature during rapid field charging.',
        metric: '< 45°C',
        metricLabel: 'Thermal Limit',
      },
      quality: {
        id: 'quality',
        title: 'Premium Quality',
        shortDesc: 'Fire-Resistant Anodized Aluminum Enclosure',
        detail: 'Aviation-grade flame-retardant casing safeguards your field transport setup.',
        metric: 'UL94-V0',
        metricLabel: 'Fire Rating',
      },
      control: {
        id: 'control',
        title: 'Remote Control',
        shortDesc: 'Bluetooth Field Diagnostics Sync',
        detail: 'Sync battery health directly to the ZIPI Pilot mobile app via Bluetooth 5.2.',
        metric: 'BT 5.2',
        metricLabel: 'Connectivity',
      },
    },
  },
  {
    id: 'prop-guard',
    name: 'ZIPI ProGuard Carbon Blades',
    category: 'accessories',
    subCategory: 'Propellers',
    tagline: 'Quiet, dynamically-balanced composite propellers.',
    description:
      'Low-noise, impact-resistant carbon composite propellers in a four-pack. Laser-balanced at the factory for smooth vibration-free aerial footage and up to 8% longer flight times.',
    price: 49,
    rating: 4.8,
    reviewCount: 310,
    image: px('3946004'),
    gallery: [px('3946004'), px('3945674')],
    colors: [{ name: 'Matte Carbon', hex: '#1c1f24' }],
    specs: {
      camera: 'Not Applicable',
      battery: 'Not Applicable',
      range: 'Not Applicable',
      maxSpeed: 'Not Applicable',
      weight: '28 g per set',
      flightTime: '+8% Extended Flight Efficiency',
    },
    highlights: ['Factory Dynamic Laser Balance', 'Wing-Tip Noise Reduction Curvature', 'Quick-Release Twist Lock'],
    showcaseFeatures: {
      shooting: {
        id: 'payload',
        title: 'Shooting Functions',
        shortDesc: 'Aero-Acoustic Vibration Suppression',
        detail: 'Minimizes micro-vibrations reaching the camera sensor to eliminate rolling shutter jello effect.',
        metric: '-3.5 dB',
        metricLabel: 'Noise Drop',
      },
      stabilization: {
        id: 'stabilization',
        title: 'Advanced Stabilization',
        shortDesc: 'Rigid Carbon Composite Pitch Hold',
        detail: 'Resists blade deflection under aggressive acceleration for crisper roll response.',
        metric: '+8%',
        metricLabel: 'Efficiency',
      },
      quality: {
        id: 'quality',
        title: 'Premium Quality',
        shortDesc: 'Reinforced Carbon Fiber Weave',
        detail: 'Survives light contact with grass, twigs, and leaves without edge nicking.',
        metric: '100% Carbon',
        metricLabel: 'Material',
      },
      control: {
        id: 'control',
        title: 'Remote Control',
        shortDesc: 'Toolless Quick-Release Mechanism',
        detail: 'Push-and-twist mounting allows rapid prop changes without wrenches or screwdrivers.',
        metric: 'Quick-Lock',
        metricLabel: 'Mounting',
      },
    },
  },
];

export const getProduct = (id: string): Product | undefined =>
  PRODUCTS.find((p) => p.id === id);

export const getProductsByCategory = (category: Category): Product[] =>
  PRODUCTS.filter((p) => p.category === category);
