import { useState } from 'react';
import { motion } from 'framer-motion';
import {
  Sprout,
  Droplets,
  Activity,
  Layers,
  Sparkles,
  ShoppingBag,
  Heart,
  TrendingUp,
  Cpu,
  Tractor,
} from 'lucide-react';
import { PRODUCTS } from '@/data/products';
import { formatPrice } from '@/lib/format';
import { useShop } from '@/hooks/useShop';
import Footer from '@/components/layout/Footer';
import DroneRender from '@/components/showcase/DroneRender';

const AGRI_BANNER =
  'https://images.pexels.com/photos/34182367/pexels-photo-34182367.jpeg?auto=compress&cs=tinysrgb&w=1920';

const AGRI_SUB_CATEGORIES = [
  'All Agriculture Systems',
  'Agricultural Spraying Drones',
  'Crop Monitoring Drones',
  'Field Mapping Drones',
  'Precision Farming Solutions',
];

export default function AgriculturePage({
  onOpenShowcase,
}: {
  onOpenShowcase: (id: string) => void;
}) {
  const { addToCart, wishlist, toggleWishlist } = useShop();
  const [selectedSubCat, setSelectedSubCat] = useState('All Agriculture Systems');

  // Interactive Agriculture Simulator States
  const [activeTab, setActiveTab] = useState<'spraying' | 'ndvi' | 'coverage' | 'efficiency'>('spraying');
  const [dropletSize, setDropletSize] = useState(150); // microns
  const [acresToCover, setAcresToCover] = useState(250);
  const [ndviMode, setNdviMode] = useState<'normal' | 'ndvi'>('ndvi');

  const agriProducts = PRODUCTS.filter((p) => p.category === 'agriculture');
  const filteredProducts =
    selectedSubCat === 'All Agriculture Systems'
      ? agriProducts
      : agriProducts.filter((p) => p.subCategory === selectedSubCat);

  // Calculations for calculator
  const flightHoursNeeded = (acresToCover / 45).toFixed(1);
  const chemicalSavingsPct = 32;
  const batterySwaps = Math.ceil(acresToCover / 45);

  return (
    <div className="bg-neutral-950 text-white min-h-screen">
      {/* ========================================================
          1. CINEMATIC AGRICULTURE HERO BANNER
          ======================================================== */}
      <section className="relative min-h-[75vh] flex items-center justify-center overflow-hidden pt-28 pb-20 px-5 sm:px-8 border-b border-emerald-500/20">
        <div className="absolute inset-0 -z-10">
          <img
            src={AGRI_BANNER}
            alt="Agricultural Spraying Drone"
            className="h-full w-full object-cover object-center opacity-30 filter brightness-90 contrast-110"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-neutral-950/90 via-neutral-950/70 to-neutral-950" />
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(16,185,129,0.18)_0,transparent_70%)]" />
        </div>

        <div className="mx-auto max-w-5xl text-center">
          <motion.div
            initial={{ opacity: 0, y: -12 }}
            animate={{ opacity: 1, y: 0 }}
            className="inline-flex items-center gap-2 rounded-full border border-emerald-500/40 bg-emerald-950/50 px-4 py-1.5 text-xs font-mono uppercase tracking-widest text-emerald-300 backdrop-blur"
          >
            <Sprout className="h-3.5 w-3.5 text-emerald-400" />
            <span>AUTONOMOUS AGRONOMY &amp; PRECISION SPRAYING</span>
          </motion.div>

          {/* Heading required by prompt */}
          <motion.h1
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.15 }}
            className="mt-6 font-display text-4xl sm:text-6xl md:text-7xl font-extrabold uppercase tracking-tight text-white"
          >
            SMARTER FARMING.{' '}
            <span className="block text-transparent bg-clip-text bg-gradient-to-r from-emerald-300 via-green-400 to-teal-200">
              BETTER HARVESTS.
            </span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="mx-auto mt-6 max-w-3xl text-base sm:text-lg text-zinc-300 font-light leading-relaxed"
          >
            Elevating modern agricultural productivity through 40-liter centrifugal atomizing sprayers, sub-centimeter RTK topographic field mapping, and synchronized 5-band NDVI multispectral scouting.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.45 }}
            className="mt-8 flex flex-wrap items-center justify-center gap-4 text-xs font-mono text-zinc-400"
          >
            <span className="flex items-center gap-1.5 rounded-md border border-white/10 bg-white/5 px-3 py-1.5">
              <Droplets className="h-3.5 w-3.5 text-emerald-400" />
              45 ACRES / HOUR EFFICIENCY
            </span>
            <span className="flex items-center gap-1.5 rounded-md border border-white/10 bg-white/5 px-3 py-1.5">
              <Activity className="h-3.5 w-3.5 text-emerald-400" />
              5-BAND MULTISPECTRAL NDVI
            </span>
            <span className="flex items-center gap-1.5 rounded-md border border-white/10 bg-white/5 px-3 py-1.5">
              <TrendingUp className="h-3.5 w-3.5 text-emerald-400" />
              UP TO 35% INPUT REDUCTION
            </span>
          </motion.div>
        </div>
      </section>

      {/* ========================================================
          2. INTERACTIVE AGRICULTURE FEATURE SHOWCASE
          Users can explore:
          - Precision spraying
          - Crop health monitoring
          - Field coverage
          - Agricultural efficiency
          ======================================================== */}
      <section className="mx-auto max-w-7xl px-5 py-16 sm:px-8">
        <div className="overflow-hidden rounded-3xl border border-emerald-500/30 bg-neutral-900/90 p-6 sm:p-10 shadow-2xl">
          {/* Navigation Tabs between the 4 required pillars */}
          <div className="flex flex-wrap items-center gap-2 border-b border-white/10 pb-6 mb-8">
            <button
              onClick={() => setActiveTab('spraying')}
              className={`flex items-center gap-2 rounded-full px-5 py-2.5 text-xs font-bold uppercase tracking-wider transition ${
                activeTab === 'spraying'
                  ? 'bg-emerald-500 text-black shadow-[0_0_20px_rgba(16,185,129,0.5)]'
                  : 'bg-white/5 text-zinc-300 hover:bg-white/10'
              }`}
            >
              <Droplets className="h-4 w-4" />
              1. Precision Spraying
            </button>
            <button
              onClick={() => setActiveTab('ndvi')}
              className={`flex items-center gap-2 rounded-full px-5 py-2.5 text-xs font-bold uppercase tracking-wider transition ${
                activeTab === 'ndvi'
                  ? 'bg-emerald-500 text-black shadow-[0_0_20px_rgba(16,185,129,0.5)]'
                  : 'bg-white/5 text-zinc-300 hover:bg-white/10'
              }`}
            >
              <Activity className="h-4 w-4" />
              2. Crop Health Monitoring
            </button>
            <button
              onClick={() => setActiveTab('coverage')}
              className={`flex items-center gap-2 rounded-full px-5 py-2.5 text-xs font-bold uppercase tracking-wider transition ${
                activeTab === 'coverage'
                  ? 'bg-emerald-500 text-black shadow-[0_0_20px_rgba(16,185,129,0.5)]'
                  : 'bg-white/5 text-zinc-300 hover:bg-white/10'
              }`}
            >
              <Layers className="h-4 w-4" />
              3. Field Coverage
            </button>
            <button
              onClick={() => setActiveTab('efficiency')}
              className={`flex items-center gap-2 rounded-full px-5 py-2.5 text-xs font-bold uppercase tracking-wider transition ${
                activeTab === 'efficiency'
                  ? 'bg-emerald-500 text-black shadow-[0_0_20px_rgba(16,185,129,0.5)]'
                  : 'bg-white/5 text-zinc-300 hover:bg-white/10'
              }`}
            >
              <TrendingUp className="h-4 w-4" />
              4. Agricultural Efficiency
            </button>
          </div>

          {/* TAB 1: PRECISION SPRAYING */}
          {activeTab === 'spraying' && (
            <div className="grid gap-8 lg:grid-cols-12 items-center">
              <div className="lg:col-span-6 space-y-4">
                <span className="text-xs font-mono uppercase tracking-widest text-emerald-400">
                  CENTRIFUGAL ATOMIZATION TECHNOLOGY
                </span>
                <h3 className="font-display text-3xl font-bold text-white">
                  Micron-Level Droplet Regulation
                </h3>
                <p className="text-sm sm:text-base text-zinc-300 leading-relaxed">
                  ZIPI’s patented magnetic centrifugal atomizers spin at 14,000 RPM, breaking liquid fertilizer into uniform micro-droplets. Adjustable droplet sizing eliminates drift in windy conditions and guarantees deep canopy under-leaf penetration.
                </p>

                {/* Droplet Size Interactive Slider */}
                <div className="rounded-2xl border border-white/10 bg-white/5 p-4 mt-6">
                  <div className="flex justify-between items-center text-xs font-mono mb-2">
                    <span className="text-zinc-400">Droplet Calibration:</span>
                    <span className="font-bold text-emerald-400">{dropletSize} Microns (μm)</span>
                  </div>
                  <input
                    type="range"
                    min="50"
                    max="500"
                    step="10"
                    value={dropletSize}
                    onChange={(e) => setDropletSize(Number(e.target.value))}
                    className="w-full accent-emerald-500 cursor-pointer"
                  />
                  <div className="flex justify-between text-[10px] text-zinc-500 font-mono mt-1">
                    <span>50μm (Ultra-Fine Orchard Fog)</span>
                    <span>250μm (Fungicide Mist)</span>
                    <span>500μm (Anti-Drift Coarse)</span>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3 pt-2">
                  <div className="rounded-xl border border-white/5 bg-white/[0.03] p-3">
                    <p className="text-[10px] text-zinc-500 uppercase">Effective Swath</p>
                    <p className="font-display text-xl font-bold text-white">12.5 Meters</p>
                  </div>
                  <div className="rounded-xl border border-white/5 bg-white/[0.03] p-3">
                    <p className="text-[10px] text-zinc-500 uppercase">Max Flow Rate</p>
                    <p className="font-display text-xl font-bold text-emerald-400">12 Liters / Min</p>
                  </div>
                </div>
              </div>

              <div className="lg:col-span-6 relative aspect-[4/3] rounded-2xl overflow-hidden bg-black">
                <img
                  src="https://images.pexels.com/photos/34182367/pexels-photo-34182367.jpeg?auto=compress&cs=tinysrgb&w=1000"
                  alt="Precision Spraying Drone over Crops"
                  className="h-full w-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
                <div className="absolute bottom-4 left-4 right-4 bg-black/70 backdrop-blur p-3 rounded-xl border border-white/10 flex justify-between items-center text-xs font-mono">
                  <span className="text-emerald-400">SPRAY STATUS: ACTIVE (RTK BOUNDARY LOCK)</span>
                  <span className="text-white">COVERAGE: 45 ACRES/HR</span>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: CROP HEALTH MONITORING (NDVI SIMULATOR) */}
          {activeTab === 'ndvi' && (
            <div className="grid gap-8 lg:grid-cols-12 items-center">
              <div className="lg:col-span-6 space-y-4">
                <span className="text-xs font-mono uppercase tracking-widest text-emerald-400">
                  5-BAND MULTISPECTRAL RADIOMETER
                </span>
                <h3 className="font-display text-3xl font-bold text-white">
                  NDVI Vegetative Index Analysis
                </h3>
                <p className="text-sm sm:text-base text-zinc-300 leading-relaxed">
                  Near-infrared (NIR) and RedEdge reflectance reveal chlorophyll density long before yellowing leaves appear. Compare standard visual photography with scientific multispectral false-color NDVI.
                </p>

                <div className="flex items-center gap-3 pt-2">
                  <button
                    onClick={() => setNdviMode('normal')}
                    className={`rounded-full px-5 py-2 text-xs font-bold uppercase transition ${
                      ndviMode === 'normal'
                        ? 'bg-white text-black'
                        : 'border border-white/20 bg-white/5 text-zinc-300'
                    }`}
                  >
                    RGB True-Color View
                  </button>
                  <button
                    onClick={() => setNdviMode('ndvi')}
                    className={`rounded-full px-5 py-2 text-xs font-bold uppercase transition ${
                      ndviMode === 'ndvi'
                        ? 'bg-emerald-500 text-black shadow-[0_0_15px_rgba(16,185,129,0.5)]'
                        : 'border border-white/20 bg-white/5 text-zinc-300'
                    }`}
                  >
                    Scientific NDVI Health Map
                  </button>
                </div>

                <div className="rounded-xl border border-white/10 bg-white/5 p-4 mt-4 space-y-2 text-xs font-mono">
                  <div className="flex items-center justify-between">
                    <span className="text-emerald-400">■ NDVI 0.8 - 1.0</span>
                    <span className="text-zinc-300">High Canopy Density (Healthy)</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-yellow-400">■ NDVI 0.4 - 0.7</span>
                    <span className="text-zinc-300">Moderate Nitrogen Stress (Spot-Treat)</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-red-400">■ NDVI &lt; 0.3</span>
                    <span className="text-zinc-300">Water Deficit / Bare Soil</span>
                  </div>
                </div>
              </div>

              <div className="lg:col-span-6 relative aspect-[4/3] rounded-2xl overflow-hidden bg-black">
                <img
                  src="https://images.pexels.com/photos/2044043/pexels-photo-2044043.jpeg?auto=compress&cs=tinysrgb&w=1000"
                  alt="Crop Health Map"
                  className={`h-full w-full object-cover transition-all duration-700 ${
                    ndviMode === 'ndvi'
                      ? 'filter hue-rotate-[90deg] saturate-200 contrast-150'
                      : ''
                  }`}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
                <div className="absolute bottom-4 left-4 right-4 bg-black/70 backdrop-blur p-3 rounded-xl border border-white/10 flex justify-between items-center text-xs font-mono">
                  <span className="text-emerald-400">
                    {ndviMode === 'ndvi' ? 'MULTISPECTRAL NIR FILTER: CALIBRATED' : 'RGB ORTHOMOSAIC SENSOR: ACTIVE'}
                  </span>
                  <span className="text-white">GSD: 1.2 CM/PX</span>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: FIELD COVERAGE & ACREAGE CALCULATOR */}
          {activeTab === 'coverage' && (
            <div className="grid gap-8 lg:grid-cols-12 items-center">
              <div className="lg:col-span-6 space-y-4">
                <span className="text-xs font-mono uppercase tracking-widest text-emerald-400">
                  REAL-TIME COVERAGE ESTIMATOR
                </span>
                <h3 className="font-display text-3xl font-bold text-white">
                  Field Coverage &amp; Battery Cycling
                </h3>
                <p className="text-sm sm:text-base text-zinc-300 leading-relaxed">
                  Calculate how fast a single ZIPI Terra Spray X40 fleet can treat your acreage. Adjust your farm acreage slider to compute cycle times.
                </p>

                <div className="rounded-2xl border border-white/10 bg-white/5 p-4 mt-4">
                  <div className="flex justify-between items-center text-xs font-mono mb-2">
                    <span className="text-zinc-400">Total Farm Acreage:</span>
                    <span className="font-bold text-emerald-400 text-base">{acresToCover} Acres</span>
                  </div>
                  <input
                    type="range"
                    min="50"
                    max="1000"
                    step="25"
                    value={acresToCover}
                    onChange={(e) => setAcresToCover(Number(e.target.value))}
                    className="w-full accent-emerald-500 cursor-pointer"
                  />
                  <div className="flex justify-between text-[10px] text-zinc-500 font-mono mt-1">
                    <span>50 Acres</span>
                    <span>500 Acres</span>
                    <span>1,000 Acres</span>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-3 pt-2">
                  <div className="rounded-xl border border-white/5 bg-white/[0.03] p-3 text-center">
                    <p className="text-[10px] text-zinc-500 uppercase">Operational Time</p>
                    <p className="font-display text-xl font-bold text-white">{flightHoursNeeded} Hours</p>
                  </div>
                  <div className="rounded-xl border border-white/5 bg-white/[0.03] p-3 text-center">
                    <p className="text-[10px] text-zinc-500 uppercase">Battery Swaps</p>
                    <p className="font-display text-xl font-bold text-white">{batterySwaps} Cycles</p>
                  </div>
                  <div className="rounded-xl border border-white/5 bg-white/[0.03] p-3 text-center">
                    <p className="text-[10px] text-zinc-500 uppercase">Chemical Reduction</p>
                    <p className="font-display text-xl font-bold text-emerald-400">-{chemicalSavingsPct}%</p>
                  </div>
                </div>
              </div>

              <div className="lg:col-span-6 relative aspect-[4/3] rounded-2xl overflow-hidden bg-black flex items-center justify-center p-6 border border-emerald-500/20">
                <DroneRender product={agriProducts[0]} className="max-h-64" />
                <div className="absolute bottom-4 left-4 right-4 bg-black/80 backdrop-blur p-3 rounded-xl border border-white/10 text-center font-mono text-xs text-emerald-400">
                  TERRA SPRAY X40 // AUTOMATED 3D ELEVATION RADAR ACTIVE
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: AGRICULTURAL EFFICIENCY & ROI */}
          {activeTab === 'efficiency' && (
            <div className="grid gap-6 sm:grid-cols-3 pt-4">
              <div className="rounded-2xl border border-white/10 bg-white/5 p-6">
                <TrendingUp className="h-8 w-8 text-emerald-400" />
                <h4 className="mt-4 font-display text-xl font-bold text-white">35% Chemical Savings</h4>
                <p className="mt-2 text-xs sm:text-sm text-zinc-400 leading-relaxed">
                  Centrifugal atomization deposits droplets directly on leaf cuticle without soil leaching or runoff into waterways.
                </p>
              </div>
              <div className="rounded-2xl border border-white/10 bg-white/5 p-6">
                <Tractor className="h-8 w-8 text-emerald-400" />
                <h4 className="mt-4 font-display text-xl font-bold text-white">Zero Soil Compaction</h4>
                <p className="mt-2 text-xs sm:text-sm text-zinc-400 leading-relaxed">
                  Heavy tractors compress root soil and damage yield up to 8%. Aerial application causes zero mechanical root disturbance.
                </p>
              </div>
              <div className="rounded-2xl border border-white/10 bg-white/5 p-6">
                <Cpu className="h-8 w-8 text-emerald-400" />
                <h4 className="mt-4 font-display text-xl font-bold text-white">Variable-Rate Spray</h4>
                <p className="mt-2 text-xs sm:text-sm text-zinc-400 leading-relaxed">
                  Direct sync with tractor terminals and Agriscan NDVI shapefiles allows micro-dosing fertilizer only where needed.
                </p>
              </div>
            </div>
          )}
        </div>
      </section>

      {/* ========================================================
          3. CATEGORY SUB-TABS
          ======================================================== */}
      <section className="mx-auto max-w-7xl px-5 pt-8 pb-4 sm:px-8">
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-2">
          {AGRI_SUB_CATEGORIES.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedSubCat(cat)}
              className={`whitespace-nowrap rounded-full px-5 py-2.5 text-xs font-semibold uppercase tracking-wider transition-all duration-300 ${
                selectedSubCat === cat
                  ? 'bg-emerald-500 text-black shadow-[0_0_20px_rgba(16,185,129,0.5)] font-bold'
                  : 'border border-white/15 bg-white/5 text-zinc-300 hover:border-white/30 hover:bg-white/10'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </section>

      {/* ========================================================
          4. AGRICULTURAL PRODUCT CARDS
          ======================================================== */}
      <section className="mx-auto max-w-7xl px-5 py-8 sm:px-8">
        <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-2">
          {filteredProducts.map((product, i) => {
            const isSaved = wishlist.includes(product.id);
            return (
              <motion.article
                key={product.id}
                initial={{ opacity: 0, y: 24 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: i * 0.1 }}
                className="group relative flex flex-col justify-between overflow-hidden rounded-3xl border border-white/10 bg-neutral-900/60 p-6 sm:p-8 transition-all duration-500 hover:border-emerald-400/80 hover:shadow-[0_0_40px_rgba(16,185,129,0.18)]"
              >
                <div>
                  <div className="flex items-center justify-between">
                    <span className="rounded-full border border-emerald-400/40 bg-emerald-950/40 px-3 py-1 text-[10px] font-mono uppercase tracking-widest text-emerald-300">
                      {product.subCategory}
                    </span>
                    <button
                      onClick={() => toggleWishlist(product.id)}
                      className={`rounded-full p-2 border transition ${
                        isSaved
                          ? 'border-red-500/50 bg-red-500/10 text-red-400'
                          : 'border-white/10 bg-white/5 text-white/60 hover:text-red-400'
                      }`}
                      aria-label="Wishlist"
                    >
                      <Heart className={`h-4 w-4 ${isSaved ? 'fill-current' : ''}`} />
                    </button>
                  </div>

                  <div
                    onClick={() => onOpenShowcase(product.id)}
                    className="relative my-6 aspect-[16/10] overflow-hidden rounded-2xl bg-neutral-950 p-4 cursor-pointer flex items-center justify-center border border-white/5 group-hover:border-emerald-500/30 transition-colors"
                  >
                    <DroneRender product={product} className="h-full w-full max-h-56" />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent pointer-events-none" />
                    <span className="absolute bottom-3 right-3 rounded-full border border-white/20 bg-black/70 px-3 py-1 text-[10px] font-mono uppercase tracking-wider text-emerald-400 backdrop-blur opacity-0 group-hover:opacity-100 transition-opacity">
                      Click for 3D Showcase
                    </span>
                  </div>

                  <h3
                    onClick={() => onOpenShowcase(product.id)}
                    className="font-display text-2xl sm:text-3xl font-bold text-white group-hover:text-emerald-300 transition-colors cursor-pointer"
                  >
                    {product.name}
                  </h3>
                  <p className="mt-2 text-xs sm:text-sm leading-relaxed text-zinc-400 line-clamp-2">
                    {product.description}
                  </p>

                  <div className="mt-6 grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs font-mono">
                    <div className="rounded-xl border border-white/5 bg-white/[0.03] p-2.5">
                      <p className="text-[10px] uppercase text-zinc-500">Payload Tank</p>
                      <p className="font-bold text-emerald-400 mt-0.5">{product.specs.payloadCapacity || '25 L'}</p>
                    </div>
                    <div className="rounded-xl border border-white/5 bg-white/[0.03] p-2.5">
                      <p className="text-[10px] uppercase text-zinc-500">Coverage Range</p>
                      <p className="font-bold text-white mt-0.5">{product.specs.range}</p>
                    </div>
                    <div className="rounded-xl border border-white/5 bg-white/[0.03] p-2.5">
                      <p className="text-[10px] uppercase text-zinc-500">Flight Time</p>
                      <p className="font-bold text-white mt-0.5">{product.specs.flightTime}</p>
                    </div>
                    <div className="rounded-xl border border-white/5 bg-white/[0.03] p-2.5">
                      <p className="text-[10px] uppercase text-zinc-500">Max Speed</p>
                      <p className="font-bold text-white mt-0.5">{product.specs.maxSpeed}</p>
                    </div>
                  </div>
                </div>

                <div className="mt-8 flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-t border-white/10 pt-6">
                  <div>
                    <span className="text-[10px] font-mono uppercase tracking-wider text-zinc-500">
                      System Investment
                    </span>
                    <div className="font-display text-2xl font-bold text-white">
                      {formatPrice(product.price)}
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => onOpenShowcase(product.id)}
                      className="flex-1 sm:flex-none inline-flex items-center justify-center gap-1.5 rounded-full border border-emerald-400/50 bg-emerald-950/30 px-5 py-2.5 text-xs font-semibold uppercase tracking-wider text-emerald-300 hover:bg-emerald-400 hover:text-black transition duration-300"
                    >
                      <Sparkles className="h-3.5 w-3.5" />
                      View Details
                    </button>

                    <button
                      onClick={() => addToCart(product.id, product.colors[0]?.name || 'Standard')}
                      className="inline-flex items-center justify-center gap-1.5 rounded-full bg-white px-5 py-2.5 text-xs font-bold uppercase tracking-wider text-black hover:bg-zinc-200 transition active:scale-95"
                    >
                      <ShoppingBag className="h-3.5 w-3.5" />
                      Add to Cart
                    </button>
                  </div>
                </div>
              </motion.article>
            );
          })}
        </div>
      </section>

      {/* ========================================================
          5. AGRICULTURAL CONSULTATION & FLEET INTEGRATION
          ======================================================== */}
      <section className="mx-auto max-w-7xl px-5 py-20 sm:px-8 border-t border-white/10">
        <div className="rounded-3xl border border-emerald-500/30 bg-neutral-900 p-8 sm:p-12 text-center max-w-4xl mx-auto">
          <Sprout className="mx-auto h-12 w-12 text-emerald-400" />
          <h3 className="mt-4 font-display text-3xl font-bold text-white">
            Commercial Farm Fleet Deployments &amp; RTK Setup
          </h3>
          <p className="mx-auto mt-3 max-w-xl text-sm sm:text-base text-zinc-300">
            Deploy multi-drone automated spray squadrons, integrate RTK base stations with John Deere or Trimble tractor telemetry, and schedule on-site flight demonstrations.
          </p>
          <div className="mt-8 flex flex-wrap justify-center gap-4">
            <a
              href="mailto:agri@zipi.aero"
              className="rounded-full bg-emerald-500 px-7 py-3 text-xs font-bold uppercase tracking-wider text-black hover:bg-emerald-400 transition"
            >
              Request Agronomy Consultation
            </a>
            <button
              onClick={() => onOpenShowcase('terra-spray-x40')}
              className="rounded-full border border-white/20 px-7 py-3 text-xs font-semibold uppercase tracking-wider text-white hover:bg-white/10 transition"
            >
              Explore Terra Spray X40
            </button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
