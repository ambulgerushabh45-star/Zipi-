import { useState } from 'react';
import { motion } from 'framer-motion';
import {
  Shield,
  Crosshair,
  Radar,
  Radio,
  Lock,
  Sparkles,
  ShoppingBag,
  Heart,
} from 'lucide-react';
import { PRODUCTS } from '@/data/products';
import { formatPrice } from '@/lib/format';
import { useShop } from '@/hooks/useShop';
import Footer from '@/components/layout/Footer';
import DroneRender from '@/components/showcase/DroneRender';

const DEFENCE_BANNER =
  'https://images.pexels.com/photos/17854251/pexels-photo-17854251.jpeg?auto=compress&cs=tinysrgb&w=1920';

const SUB_CATEGORIES = [
  'All Defence Systems',
  'Surveillance Drones',
  'Reconnaissance Drones',
  'Security Monitoring Drones',
  'Search and Rescue Drones',
];

export default function DefencePage({
  onOpenShowcase,
}: {
  onOpenShowcase: (id: string) => void;
}) {
  const { addToCart, wishlist, toggleWishlist } = useShop();
  const [selectedSubCat, setSelectedSubCat] = useState('All Defence Systems');
  const [thermalViewActive, setThermalViewActive] = useState(false);

  const defenceProducts = PRODUCTS.filter((p) => p.category === 'defence');
  const filteredProducts =
    selectedSubCat === 'All Defence Systems'
      ? defenceProducts
      : defenceProducts.filter((p) => p.subCategory === selectedSubCat);

  return (
    <div className="bg-black text-white min-h-screen">
      {/* ========================================================
          1. CINEMATIC DEFENCE HERO BANNER
          ======================================================== */}
      <section className="relative min-h-[75vh] flex items-center justify-center overflow-hidden pt-28 pb-20 px-5 sm:px-8 border-b border-cyan-500/20">
        {/* Banner Imagery & Dark Gradients */}
        <div className="absolute inset-0 -z-10">
          <img
            src={DEFENCE_BANNER}
            alt="ZIPI Defence Aircraft Platform"
            className="h-full w-full object-cover object-center opacity-30 filter brightness-75 contrast-125"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-black/90 via-black/70 to-black" />
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(0,229,255,0.15)_0,transparent_70%)]" />
        </div>

        {/* Tactical Crosshair Watermark */}
        <div className="pointer-events-none absolute right-10 top-32 opacity-15 hidden lg:block">
          <Crosshair className="h-64 w-64 text-cyan-400 stroke-[0.5]" />
        </div>

        <div className="mx-auto max-w-5xl text-center">
          <motion.div
            initial={{ opacity: 0, y: -12 }}
            animate={{ opacity: 1, y: 0 }}
            className="inline-flex items-center gap-2 rounded-full border border-cyan-500/40 bg-cyan-950/50 px-4 py-1.5 text-xs font-mono uppercase tracking-widest text-cyan-300 backdrop-blur"
          >
            <Shield className="h-3.5 w-3.5 text-cyan-400" />
            <span>LAWFUL TACTICAL ISR &amp; PERIMETER SURVEILLANCE</span>
          </motion.div>

          {/* Heading required by prompt */}
          <motion.h1
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.15 }}
            className="mt-6 font-display text-4xl sm:text-6xl md:text-7xl font-extrabold uppercase tracking-tight text-white"
          >
            PRECISION IN THE AIR.{' '}
            <span className="block text-transparent bg-clip-text bg-gradient-to-r from-cyan-300 via-cyan-400 to-sky-200">
              CONFIDENCE ON THE GROUND.
            </span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="mx-auto mt-6 max-w-3xl text-base sm:text-lg text-zinc-300 font-light leading-relaxed"
          >
            ZIPI Defence delivers high-endurance, non-weaponized aerial systems designed strictly for tactical surveillance, border observation, infrastructure protection, and high-altitude humanitarian rescue.
          </motion.p>

          {/* Tactical Verification Badges */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.45 }}
            className="mt-8 flex flex-wrap items-center justify-center gap-4 text-xs font-mono text-zinc-400"
          >
            <span className="flex items-center gap-1.5 rounded-md border border-white/10 bg-white/5 px-3 py-1.5">
              <Lock className="h-3.5 w-3.5 text-cyan-400" />
              AES-256 ENCRYPTED C2
            </span>
            <span className="flex items-center gap-1.5 rounded-md border border-white/10 bg-white/5 px-3 py-1.5">
              <Radar className="h-3.5 w-3.5 text-cyan-400" />
              NON-WEAPONIZED ISR
            </span>
            <span className="flex items-center gap-1.5 rounded-md border border-white/10 bg-white/5 px-3 py-1.5">
              <Radio className="h-3.5 w-3.5 text-cyan-400" />
              ANTI-JAMMING FREQ HOP
            </span>
          </motion.div>
        </div>
      </section>

      {/* ========================================================
          2. INTERACTIVE TACTICAL EO/IR THERMAL VIEWER SIMULATOR
          ======================================================== */}
      <section className="mx-auto max-w-7xl px-5 py-12 sm:px-8">
        <div className="relative overflow-hidden rounded-3xl border border-cyan-500/30 bg-neutral-950 p-6 sm:p-10 shadow-2xl">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 border-b border-white/10 pb-6 mb-8">
            <div>
              <span className="text-xs font-mono uppercase tracking-widest text-cyan-400">
                LIVE OPTICAL SIMULATOR
              </span>
              <h3 className="text-2xl font-bold font-display text-white mt-1">
                Daylight EO Zoom vs. Radiometric FLIR Thermal
              </h3>
            </div>
            <div className="flex items-center gap-3">
              <span className="text-xs uppercase font-mono text-zinc-400">Sensor Mode:</span>
              <button
                onClick={() => setThermalViewActive(false)}
                className={`rounded-full px-4 py-1.5 text-xs font-bold uppercase transition ${
                  !thermalViewActive
                    ? 'bg-cyan-400 text-black shadow-[0_0_15px_rgba(0,229,255,0.6)]'
                    : 'bg-white/10 text-white/70 hover:text-white'
                }`}
              >
                Daylight EO 4K
              </button>
              <button
                onClick={() => setThermalViewActive(true)}
                className={`rounded-full px-4 py-1.5 text-xs font-bold uppercase transition ${
                  thermalViewActive
                    ? 'bg-purple-500 text-white shadow-[0_0_15px_rgba(168,85,247,0.6)]'
                    : 'bg-white/10 text-white/70 hover:text-white'
                }`}
              >
                Radiometric FLIR
              </button>
            </div>
          </div>

          <div className="relative aspect-[16/8] sm:aspect-[21/9] w-full overflow-hidden rounded-2xl bg-black">
            <img
              src={
                thermalViewActive
                  ? 'https://images.pexels.com/photos/6493443/pexels-photo-6493443.jpeg?auto=compress&cs=tinysrgb&w=1400'
                  : 'https://images.pexels.com/photos/17854251/pexels-photo-17854251.jpeg?auto=compress&cs=tinysrgb&w=1400'
              }
              alt="Optical Sensor View"
              className={`h-full w-full object-cover transition-all duration-700 ${
                thermalViewActive
                  ? 'filter hue-rotate-[180deg] invert brightness-125 contrast-200'
                  : 'filter brightness-90 contrast-110'
              }`}
            />

            {/* Tactical HUD Overlay Over Image */}
            <div className="absolute inset-0 pointer-events-none p-6 flex flex-col justify-between">
              <div className="flex justify-between items-start font-mono text-xs text-cyan-400">
                <div className="bg-black/60 px-3 py-1.5 rounded border border-cyan-400/40 backdrop-blur">
                  ZOOM: 40.0x CONTINUOUS // FLIR: 640x512
                </div>
                <div className="bg-black/60 px-3 py-1.5 rounded border border-cyan-400/40 backdrop-blur text-right">
                  BEARING: 042° NE // TILT: -14.2° // ELEV: 1,420M
                </div>
              </div>

              {/* Center Target Box */}
              <div className="mx-auto flex h-24 w-24 items-center justify-center border border-cyan-400/60 rounded">
                <Crosshair className="h-10 w-10 text-cyan-400 animate-pulse" />
              </div>

              <div className="flex justify-between items-end font-mono text-[11px] text-zinc-300">
                <span className="bg-black/60 px-3 py-1 rounded border border-white/10">
                  {thermalViewActive ? 'TARGET TEMP: 37.2°C [SURVIVOR DETECTED]' : 'OPTICAL RESOLUTION: 3840 x 2160'}
                </span>
                <span className="bg-black/60 px-3 py-1 rounded border border-white/10 text-cyan-400">
                  AES-256 TELEMETRY LOCKED
                </span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ========================================================
          3. CATEGORY FILTER TABS
          ======================================================== */}
      <section className="mx-auto max-w-7xl px-5 pt-12 pb-6 sm:px-8">
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-2">
          {SUB_CATEGORIES.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedSubCat(cat)}
              className={`whitespace-nowrap rounded-full px-5 py-2.5 text-xs font-semibold uppercase tracking-wider transition-all duration-300 ${
                selectedSubCat === cat
                  ? 'bg-cyan-400 text-black shadow-[0_0_20px_rgba(0,229,255,0.5)] font-bold'
                  : 'border border-white/15 bg-white/5 text-zinc-300 hover:border-white/30 hover:bg-white/10'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </section>

      {/* ========================================================
          4. INTERACTIVE DEFENCE PRODUCT CARDS GRID
          ======================================================== */}
      <section className="mx-auto max-w-7xl px-5 py-10 sm:px-8">
        <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-2">
          {filteredProducts.map((product, i) => {
            const isSaved = wishlist.includes(product.id);
            return (
              <motion.article
                key={product.id}
                initial={{ opacity: 0, y: 24 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: i * 0.1 }}
                className="group relative flex flex-col justify-between overflow-hidden rounded-3xl border border-white/10 bg-neutral-950 p-6 sm:p-8 transition-all duration-500 hover:border-cyan-400/80 hover:shadow-[0_0_40px_rgba(0,229,255,0.18)]"
              >
                <div>
                  {/* Top Bar: Subcategory & Wishlist */}
                  <div className="flex items-center justify-between">
                    <span className="rounded-full border border-cyan-400/40 bg-cyan-950/40 px-3 py-1 text-[10px] font-mono uppercase tracking-widest text-cyan-300">
                      {product.subCategory}
                    </span>
                    <button
                      onClick={() => toggleWishlist(product.id)}
                      className={`rounded-full p-2 border transition ${
                        isSaved
                          ? 'border-red-500/50 bg-red-500/10 text-red-400'
                          : 'border-white/10 bg-white/5 text-white/60 hover:text-red-400'
                      }`}
                      aria-label="Wishlist"
                    >
                      <Heart className={`h-4 w-4 ${isSaved ? 'fill-current' : ''}`} />
                    </button>
                  </div>

                  {/* Drone Image Render with Parallax Hover */}
                  <div
                    onClick={() => onOpenShowcase(product.id)}
                    className="relative my-6 aspect-[16/10] overflow-hidden rounded-2xl bg-neutral-900/60 p-4 cursor-pointer flex items-center justify-center border border-white/5 group-hover:border-cyan-500/30 transition-colors"
                  >
                    <DroneRender product={product} className="h-full w-full max-h-56" />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent pointer-events-none" />
                    <span className="absolute bottom-3 right-3 rounded-full border border-white/20 bg-black/70 px-3 py-1 text-[10px] font-mono uppercase tracking-wider text-cyan-400 backdrop-blur opacity-0 group-hover:opacity-100 transition-opacity">
                      Click for 3D Showcase
                    </span>
                  </div>

                  {/* Title & Description */}
                  <h3
                    onClick={() => onOpenShowcase(product.id)}
                    className="font-display text-2xl sm:text-3xl font-bold text-white group-hover:text-cyan-300 transition-colors cursor-pointer"
                  >
                    {product.name}
                  </h3>
                  <p className="mt-2 text-xs sm:text-sm leading-relaxed text-zinc-400 line-clamp-2">
                    {product.description}
                  </p>

                  {/* Key Specifications Grid */}
                  <div className="mt-6 grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs font-mono">
                    <div className="rounded-xl border border-white/5 bg-white/[0.03] p-2.5">
                      <p className="text-[10px] uppercase text-zinc-500">Flight Time</p>
                      <p className="font-bold text-white mt-0.5">{product.specs.flightTime}</p>
                    </div>
                    <div className="rounded-xl border border-white/5 bg-white/[0.03] p-2.5">
                      <p className="text-[10px] uppercase text-zinc-500">Operational Range</p>
                      <p className="font-bold text-white mt-0.5">{product.specs.range}</p>
                    </div>
                    <div className="rounded-xl border border-white/5 bg-white/[0.03] p-2.5">
                      <p className="text-[10px] uppercase text-zinc-500">Wind Rating</p>
                      <p className="font-bold text-white mt-0.5">{product.specs.windResistance || 'Level 8'}</p>
                    </div>
                    <div className="rounded-xl border border-white/5 bg-white/[0.03] p-2.5">
                      <p className="text-[10px] uppercase text-zinc-500">Encryption</p>
                      <p className="font-bold text-cyan-400 mt-0.5">{product.specs.encryption?.split(' ')[0] || 'AES-256'}</p>
                    </div>
                  </div>
                </div>

                {/* Bottom Actions: Price, View Details, Add to Cart */}
                <div className="mt-8 flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-t border-white/10 pt-6">
                  <div>
                    <span className="text-[10px] font-mono uppercase tracking-wider text-zinc-500">
                      Procurement Price
                    </span>
                    <div className="font-display text-2xl font-bold text-white">
                      {formatPrice(product.price)}
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => onOpenShowcase(product.id)}
                      className="flex-1 sm:flex-none inline-flex items-center justify-center gap-1.5 rounded-full border border-cyan-400/50 bg-cyan-950/30 px-5 py-2.5 text-xs font-semibold uppercase tracking-wider text-cyan-300 hover:bg-cyan-400 hover:text-black transition duration-300"
                    >
                      <Sparkles className="h-3.5 w-3.5" />
                      View Details
                    </button>

                    <button
                      onClick={() => addToCart(product.id, product.colors[0]?.name || 'Standard')}
                      className="inline-flex items-center justify-center gap-1.5 rounded-full bg-white px-5 py-2.5 text-xs font-bold uppercase tracking-wider text-black hover:bg-zinc-200 transition active:scale-95"
                    >
                      <ShoppingBag className="h-3.5 w-3.5" />
                      Add to Cart
                    </button>
                  </div>
                </div>
              </motion.article>
            );
          })}
        </div>
      </section>

      {/* ========================================================
          5. DEFENCE CONTRACTOR INQUIRY / RFP SECTION
          ======================================================== */}
      <section className="mx-auto max-w-7xl px-5 py-20 sm:px-8 border-t border-white/10">
        <div className="rounded-3xl border border-cyan-500/30 bg-neutral-950 p-8 sm:p-12 text-center max-w-4xl mx-auto">
          <Shield className="mx-auto h-12 w-12 text-cyan-400" />
          <h3 className="mt-4 font-display text-3xl font-bold text-white">
            Custom Defense &amp; Security Fleet Integrations
          </h3>
          <p className="mx-auto mt-3 max-w-xl text-sm sm:text-base text-zinc-300">
            For governmental tenders, border security integration, encrypted C2 frequencies, and rapid-response search and rescue fleets, connect directly with our aerospace engineering team.
          </p>
          <div className="mt-8 flex flex-wrap justify-center gap-4">
            <a
              href="mailto:defence@zipi.aero"
              className="rounded-full bg-cyan-400 px-7 py-3 text-xs font-bold uppercase tracking-wider text-black hover:bg-cyan-300 transition"
            >
              Request Tactical Dossier
            </a>
            <button
              onClick={() => onOpenShowcase('aegis-mk4')}
              className="rounded-full border border-white/20 px-7 py-3 text-xs font-semibold uppercase tracking-wider text-white hover:bg-white/10 transition"
            >
              Launch Aegis MK-IV Showcase
            </button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
