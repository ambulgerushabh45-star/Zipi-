import { useState, useMemo } from 'react';
import { useSearchParams } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Search,
  SlidersHorizontal,
  Sparkles,
  Eye,
  Heart,
  Plus,
  Layers,
  X,
} from 'lucide-react';
import { PRODUCTS, CATEGORY_LABELS, type Product } from '@/data/products';
import { formatPrice } from '@/lib/format';
import { useShop } from '@/hooks/useShop';
import QuickViewModal from '@/components/product/QuickViewModal';
import StarRating from '@/components/product/StarRating';
import Footer from '@/components/layout/Footer';
import DroneRender from '@/components/showcase/DroneRender';

const FILTER_TABS: { id: string; label: string }[] = [
  { id: 'all', label: 'All Systems' },
  { id: 'defence', label: 'Defence & Security' },
  { id: 'agriculture', label: 'Agriculture & Farming' },
  { id: 'commercial', label: 'Commercial & Industrial' },
  { id: 'camera', label: 'Camera & Cinematography' },
  { id: 'accessories', label: 'Accessories' },
];

export default function ProductsPage({
  onOpenShowcase,
}: {
  onOpenShowcase: (id: string) => void;
}) {
  const [searchParams] = useSearchParams();
  const initialCategory = searchParams.get('category') || 'all';
  const initialSearch = searchParams.get('q') || '';

  const { wishlist, toggleWishlist, addToCart, compare, toggleCompare, removeFromCompare } = useShop();

  const [selectedCategory, setSelectedCategory] = useState<string>(initialCategory);
  const [searchQuery, setSearchQuery] = useState(initialSearch);
  const [sortBy, setSortBy] = useState<'featured' | 'price-asc' | 'price-desc' | 'rating'>('featured');
  const [quickViewProduct, setQuickViewProduct] = useState<Product | null>(null);
  const [compareModalOpen, setCompareModalOpen] = useState(false);

  // Filtered and Sorted Products
  const filteredProducts = useMemo(() => {
    return PRODUCTS.filter((p) => {
      // Category filter
      if (selectedCategory !== 'all') {
        if (selectedCategory === 'commercial') {
          if (p.category !== 'commercial' && p.category !== 'fpv' && p.category !== 'mini') return false;
        } else if (p.category !== selectedCategory) {
          return false;
        }
      }

      // Search query filter
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        const matchesName = p.name.toLowerCase().includes(query);
        const matchesDesc = p.description.toLowerCase().includes(query);
        const matchesCat = (p.subCategory || '').toLowerCase().includes(query);
        const matchesHighlights = p.highlights.some((h) => h.toLowerCase().includes(query));
        if (!matchesName && !matchesDesc && !matchesCat && !matchesHighlights) return false;
      }

      return true;
    }).sort((a, b) => {
      if (sortBy === 'price-asc') return a.price - b.price;
      if (sortBy === 'price-desc') return b.price - a.price;
      if (sortBy === 'rating') return b.rating - a.rating;
      return 0; // featured default order
    });
  }, [selectedCategory, searchQuery, sortBy]);

  const comparedProducts = useMemo(
    () => compare.map((id) => PRODUCTS.find((p) => p.id === id)).filter(Boolean) as Product[],
    [compare]
  );

  return (
    <div className="min-h-screen bg-neutral-950 text-white pt-24">
      {/* Header Bar */}
      <section className="mx-auto max-w-7xl px-5 py-12 sm:px-8 border-b border-white/10">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
          <div>
            <span className="text-xs font-mono uppercase tracking-[0.25em] text-cyan-400">
              FLEET HARDWARE CATALOG
            </span>
            <h1 className="mt-2 font-display text-4xl sm:text-5xl font-extrabold text-white">
              Autonomous Aerial Systems
            </h1>
            <p className="mt-2 max-w-xl text-sm text-zinc-400 leading-relaxed">
              Explore defence surveillance platforms, heavy-payload agricultural sprayers, and cinema-grade commercial UAVs.
            </p>
          </div>

          {/* Quick Counter */}
          <div className="flex items-center gap-3 font-mono text-xs text-zinc-400">
            <span className="rounded-full border border-white/10 bg-white/5 px-4 py-1.5">
              Showing <strong className="text-white">{filteredProducts.length}</strong> Aircraft
            </span>
            {compare.length > 0 && (
              <button
                onClick={() => setCompareModalOpen(true)}
                className="flex items-center gap-2 rounded-full border border-cyan-400/50 bg-cyan-950/40 px-4 py-1.5 text-cyan-300 hover:bg-cyan-400 hover:text-black transition"
              >
                <Layers className="h-3.5 w-3.5" />
                <span>Compare ({compare.length}/3)</span>
              </button>
            )}
          </div>
        </div>

        {/* Search & Sort Controls */}
        <div className="mt-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          {/* Search Input */}
          <div className="relative w-full sm:max-w-md">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-zinc-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search drones by mission, sensor, model..."
              className="w-full rounded-full border border-white/15 bg-white/5 pl-11 pr-10 py-2.5 text-sm text-white placeholder:text-zinc-500 focus:outline-none focus:border-cyan-400 transition"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3.5 top-1/2 -translate-y-1/2 text-zinc-400 hover:text-white"
              >
                <X className="h-4 w-4" />
              </button>
            )}
          </div>

          {/* Sort Selector */}
          <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
            <SlidersHorizontal className="h-4 w-4 text-zinc-400" />
            <span className="text-xs uppercase text-zinc-400">Sort:</span>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as 'featured' | 'price-asc' | 'price-desc' | 'rating')}
              className="rounded-full border border-white/15 bg-white/5 px-4 py-2 text-xs font-semibold uppercase text-white focus:outline-none focus:border-cyan-400 cursor-pointer"
            >
              <option value="featured" className="bg-neutral-900">Featured Missions</option>
              <option value="price-asc" className="bg-neutral-900">Price: Low to High</option>
              <option value="price-desc" className="bg-neutral-900">Price: High to Low</option>
              <option value="rating" className="bg-neutral-900">Highest Pilot Rating</option>
            </select>
          </div>
        </div>

        {/* Category Tabs */}
        <div className="mt-8 flex items-center gap-2 overflow-x-auto no-scrollbar pb-2">
          {FILTER_TABS.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setSelectedCategory(tab.id)}
              className={`whitespace-nowrap rounded-full px-5 py-2.5 text-xs font-semibold uppercase tracking-wider transition-all duration-300 ${
                selectedCategory === tab.id
                  ? 'bg-cyan-400 text-black shadow-[0_0_20px_rgba(0,229,255,0.5)] font-bold'
                  : 'border border-white/15 bg-white/5 text-zinc-300 hover:border-white/30 hover:bg-white/10'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </section>

      {/* Product Discovery Grid */}
      <section className="mx-auto max-w-7xl px-5 py-14 sm:px-8">
        {filteredProducts.length === 0 ? (
          <div className="rounded-3xl border border-white/10 bg-white/5 p-16 text-center">
            <Search className="mx-auto h-12 w-12 text-zinc-600" />
            <h3 className="mt-4 text-xl font-bold font-display">No Drones Matching Criteria</h3>
            <p className="mt-2 text-sm text-zinc-400">Try adjusting your search query or switching categories.</p>
            <button
              onClick={() => {
                setSearchQuery('');
                setSelectedCategory('all');
              }}
              className="mt-6 rounded-full bg-cyan-400 px-6 py-2.5 text-xs font-bold uppercase tracking-wider text-black hover:bg-cyan-300"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {filteredProducts.map((product, i) => {
              const isSaved = wishlist.includes(product.id);
              const isCompared = compare.includes(product.id);

              return (
                <motion.article
                  key={product.id}
                  initial={{ opacity: 0, y: 24 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: (i % 6) * 0.08 }}
                  className="group relative flex flex-col justify-between overflow-hidden rounded-3xl border border-white/10 bg-neutral-900/60 p-5 transition-all duration-500 hover:border-cyan-400/60 hover:shadow-[0_0_30px_rgba(0,229,255,0.14)]"
                >
                  <div>
                    {/* Top Badges & Actions */}
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1.5">
                        <span className="rounded-full bg-white/10 px-2.5 py-0.5 text-[10px] font-mono uppercase tracking-wider text-cyan-300">
                          {CATEGORY_LABELS[product.category] || product.category}
                        </span>
                        {product.badge && (
                          <span className="rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 px-2 py-0.5 text-[9px] font-bold uppercase tracking-wider">
                            {product.badge}
                          </span>
                        )}
                      </div>

                      <div className="flex items-center gap-1.5">
                        {/* Compare toggle */}
                        <button
                          onClick={() => toggleCompare(product.id)}
                          className={`rounded-full p-1.5 border transition text-xs ${
                            isCompared
                              ? 'border-cyan-400 bg-cyan-400 text-black'
                              : 'border-white/10 bg-white/5 text-zinc-400 hover:text-white'
                          }`}
                          title={isCompared ? 'Remove from compare' : 'Add to compare'}
                        >
                          <Layers className="h-3.5 w-3.5" />
                        </button>

                        {/* Wishlist toggle */}
                        <button
                          onClick={() => toggleWishlist(product.id)}
                          className={`rounded-full p-1.5 border transition ${
                            isSaved
                              ? 'border-red-500/50 bg-red-500/20 text-red-400'
                              : 'border-white/10 bg-white/5 text-zinc-400 hover:text-red-400'
                          }`}
                          aria-label="Wishlist"
                        >
                          <Heart className={`h-3.5 w-3.5 ${isSaved ? 'fill-current' : ''}`} />
                        </button>
                      </div>
                    </div>

                    {/* Image Area with 3D Render & Quick View on Hover */}
                    <div
                      onClick={() => onOpenShowcase(product.id)}
                      className="relative my-4 aspect-[4/3] overflow-hidden rounded-2xl bg-neutral-950 p-4 cursor-pointer flex items-center justify-center border border-white/5 group-hover:border-white/20 transition-all"
                    >
                      <DroneRender product={product} className="h-full w-full max-h-48" />

                      {/* Hover Overlay with Quick View button */}
                      <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 backdrop-blur-xs flex items-center justify-center gap-3 transition-opacity duration-300">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setQuickViewProduct(product);
                          }}
                          className="flex items-center gap-1.5 rounded-full bg-white/90 px-3.5 py-1.5 text-xs font-semibold text-black hover:bg-white shadow"
                        >
                          <Eye className="h-3.5 w-3.5" />
                          Quick View
                        </button>
                        <button
                          onClick={() => onOpenShowcase(product.id)}
                          className="flex items-center gap-1.5 rounded-full bg-cyan-400 px-3.5 py-1.5 text-xs font-bold text-black hover:bg-cyan-300 shadow"
                        >
                          <Sparkles className="h-3.5 w-3.5" />
                          3D Showcase
                        </button>
                      </div>
                    </div>

                    {/* Name & Tagline */}
                    <h3
                      onClick={() => onOpenShowcase(product.id)}
                      className="font-display text-xl font-bold text-white group-hover:text-cyan-300 transition-colors cursor-pointer"
                    >
                      {product.name}
                    </h3>
                    <p className="mt-1 text-xs text-zinc-400 line-clamp-1">
                      {product.tagline}
                    </p>

                    {/* Star Rating */}
                    <div className="mt-2">
                      <StarRating rating={product.rating} count={product.reviewCount} size={11} />
                    </div>

                    {/* SPECS REVEAL ON HOVER (Requirement 6) */}
                    <div className="mt-4 pt-3 border-t border-white/5 space-y-1.5 text-[11px] font-mono text-zinc-400 group-hover:text-zinc-200 transition-colors">
                      <div className="flex justify-between">
                        <span>Flight Time:</span>
                        <strong className="text-white">{product.specs.flightTime}</strong>
                      </div>
                      <div className="flex justify-between">
                        <span>Operating Range:</span>
                        <strong className="text-white">{product.specs.range}</strong>
                      </div>
                      <div className="flex justify-between">
                        <span>Max Speed:</span>
                        <strong className="text-white">{product.specs.maxSpeed}</strong>
                      </div>
                      {product.specs.payloadCapacity && (
                        <div className="flex justify-between text-cyan-400">
                          <span>Payload Capacity:</span>
                          <strong>{product.specs.payloadCapacity}</strong>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Pricing and Action */}
                  <div className="mt-6 flex items-center justify-between border-t border-white/10 pt-4">
                    <div>
                      {product.originalPrice && (
                        <span className="text-[11px] text-zinc-500 line-through block">
                          {formatPrice(product.originalPrice)}
                        </span>
                      )}
                      <span className="font-display text-xl font-bold text-white">
                        {formatPrice(product.price)}
                      </span>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => addToCart(product.id, product.colors[0]?.name || 'Standard')}
                        className="flex items-center gap-1 rounded-full bg-white px-3.5 py-2 text-xs font-bold uppercase tracking-wider text-black hover:bg-zinc-200 transition active:scale-95"
                      >
                        <Plus className="h-3.5 w-3.5" />
                        Add
                      </button>
                    </div>
                  </div>
                </motion.article>
              );
            })}
          </div>
        )}
      </section>

      {/* QUICK VIEW MODAL */}
      <AnimatePresence>
        {quickViewProduct && (
          <QuickViewModal
            product={quickViewProduct}
            onClose={() => setQuickViewProduct(null)}
          />
        )}
      </AnimatePresence>

      {/* SIDE-BY-SIDE DRONE COMPARISON MODAL */}
      <AnimatePresence>
        {compareModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setCompareModalOpen(false)}
              className="absolute inset-0 bg-black/80 backdrop-blur-md"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="relative w-full max-w-5xl max-h-[90vh] overflow-y-auto rounded-3xl border border-white/20 bg-neutral-900 p-6 sm:p-8 text-white shadow-2xl"
            >
              <div className="flex items-center justify-between border-b border-white/10 pb-4">
                <div>
                  <span className="text-xs font-mono uppercase tracking-widest text-cyan-400">
                    SIDE-BY-SIDE TECHNICAL MATRIX
                  </span>
                  <h3 className="text-2xl font-bold font-display">Compare Fleet Hardware</h3>
                </div>
                <button
                  onClick={() => setCompareModalOpen(false)}
                  className="rounded-full bg-white/10 p-2 hover:bg-white/20 text-white"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>

              {comparedProducts.length === 0 ? (
                <div className="py-12 text-center text-zinc-400">
                  <p>No aircraft selected for comparison yet.</p>
                  <p className="text-xs mt-1">Check the layers icon on any product card to compare.</p>
                </div>
              ) : (
                <div className="mt-6 overflow-x-auto">
                  <table className="w-full text-left text-xs font-mono border-collapse">
                    <thead>
                      <tr className="border-b border-white/10">
                        <th className="py-3 px-4 text-zinc-400 uppercase w-1/4">Specification</th>
                        {comparedProducts.map((p) => (
                          <th key={p.id} className="py-3 px-4 text-white text-base font-display">
                            <div className="flex justify-between items-start">
                              <div>
                                <p className="font-bold">{p.name}</p>
                                <p className="text-cyan-400 font-mono text-sm mt-0.5">{formatPrice(p.price)}</p>
                              </div>
                              <button
                                onClick={() => removeFromCompare(p.id)}
                                className="text-zinc-500 hover:text-red-400 p-1"
                              >
                                <X className="h-4 w-4" />
                              </button>
                            </div>
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-white/5">
                      <tr>
                        <td className="py-3 px-4 text-zinc-400 uppercase">Sector Category</td>
                        {comparedProducts.map((p) => (
                          <td key={p.id} className="py-3 px-4 font-semibold text-white">
                            {CATEGORY_LABELS[p.category]}
                          </td>
                        ))}
                      </tr>
                      <tr>
                        <td className="py-3 px-4 text-zinc-400 uppercase">Flight Endurance</td>
                        {comparedProducts.map((p) => (
                          <td key={p.id} className="py-3 px-4 text-cyan-300 font-bold">
                            {p.specs.flightTime}
                          </td>
                        ))}
                      </tr>
                      <tr>
                        <td className="py-3 px-4 text-zinc-400 uppercase">Operating Range</td>
                        {comparedProducts.map((p) => (
                          <td key={p.id} className="py-3 px-4 text-white">
                            {p.specs.range}
                          </td>
                        ))}
                      </tr>
                      <tr>
                        <td className="py-3 px-4 text-zinc-400 uppercase">Top Speed</td>
                        {comparedProducts.map((p) => (
                          <td key={p.id} className="py-3 px-4 text-white">
                            {p.specs.maxSpeed}
                          </td>
                        ))}
                      </tr>
                      <tr>
                        <td className="py-3 px-4 text-zinc-400 uppercase">Camera / Sensor Payload</td>
                        {comparedProducts.map((p) => (
                          <td key={p.id} className="py-3 px-4 text-zinc-300">
                            {p.specs.camera}
                          </td>
                        ))}
                      </tr>
                      <tr>
                        <td className="py-3 px-4 text-zinc-400 uppercase">Payload Capacity</td>
                        {comparedProducts.map((p) => (
                          <td key={p.id} className="py-3 px-4 text-emerald-400 font-bold">
                            {p.specs.payloadCapacity || 'Internal gimbal only'}
                          </td>
                        ))}
                      </tr>
                      <tr>
                        <td className="py-3 px-4 text-zinc-400 uppercase">Wind Resistance</td>
                        {comparedProducts.map((p) => (
                          <td key={p.id} className="py-3 px-4 text-white">
                            {p.specs.windResistance || 'Level 6'}
                          </td>
                        ))}
                      </tr>
                      <tr>
                        <td className="py-3 px-4 text-zinc-400 uppercase">Actions</td>
                        {comparedProducts.map((p) => (
                          <td key={p.id} className="py-3 px-4">
                            <button
                              onClick={() => {
                                setCompareModalOpen(false);
                                onOpenShowcase(p.id);
                              }}
                              className="rounded-full bg-cyan-400 px-4 py-2 text-xs font-bold uppercase text-black hover:bg-cyan-300"
                            >
                              Launch 3D Showcase
                            </button>
                          </td>
                        ))}
                      </tr>
                    </tbody>
                  </table>
                </div>
              )}
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <Footer />
    </div>
  );
}
